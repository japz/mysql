mySQMWEB
A graphical web based interface running on Apache or Raspberry PI that takes the values from a mySQM+ controller to a graphical Web page(s)

Please view the video and see values change in real time.

Please view the PDF in this zip file for instructions on how mySQMWEB can be installed.
https://sourceforge.net/projects/mysqmproesp32/files/mySQMWEB/

For further information, download the PDF for this project
https://sourceforge.net/projects/mysqmproesp32/files/DOCUMENTATION/
