mySQM+ JSON-LOGGER Windows Application
(c) Robert Brown 2021, All rights reserved.
rbb1brown@gmail.com

Permission is granted for personal/academic/education use only.


0.0.0.6
Add rain tab
Add rain chart
Fix error in Wind chart

0.0.0.5
add avg wind speed
add max wind gust
add wind chart to wind tab

0.0.0.4
Fix for invalid time in JSON log

0.0.0.3
Fix for invalid controllertype in JSON response

0.0.0.2
Updated to new protocol and firmware 125
Change visual appearance of text fields due to Win11 changes

0.0.0.1
Create application
Add selective data tab
Use Invariant Culture for saving data to log files