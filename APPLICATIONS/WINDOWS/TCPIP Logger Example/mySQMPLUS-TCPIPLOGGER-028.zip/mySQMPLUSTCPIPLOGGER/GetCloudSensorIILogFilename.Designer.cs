﻿namespace mySQMPLUSTCPIPLOGGER
{
    partial class GetCloudSensorIILogFilename
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GetCloudSensorIILogFilename));
            this.CloseBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.filename = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // CloseBtn
            // 
            this.CloseBtn.Location = new System.Drawing.Point(648, 303);
            this.CloseBtn.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.CloseBtn.Name = "CloseBtn";
            this.CloseBtn.Size = new System.Drawing.Size(218, 76);
            this.CloseBtn.TabIndex = 80;
            this.CloseBtn.Text = "Close";
            this.CloseBtn.UseVisualStyleBackColor = true;
            this.CloseBtn.Click += new System.EventHandler(this.CloseBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 46);
            this.label1.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(148, 37);
            this.label1.TabIndex = 82;
            this.label1.Text = "Filename";
            // 
            // filename
            // 
            this.filename.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.filename.DataBindings.Add(new System.Windows.Forms.Binding("Text", global::mySQMPLUSTCPIPLOGGER.Properties.Settings.Default, "CloudSensorIILogFilename", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.filename.Location = new System.Drawing.Point(28, 97);
            this.filename.Margin = new System.Windows.Forms.Padding(7);
            this.filename.Name = "filename";
            this.filename.Size = new System.Drawing.Size(833, 44);
            this.filename.TabIndex = 81;
            this.filename.Text = global::mySQMPLUSTCPIPLOGGER.Properties.Settings.Default.CloudSensorIILogFilename;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(38, 180);
            this.label2.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(321, 37);
            this.label2.TabIndex = 83;
            this.label2.Text = "Do not include a path";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(38, 243);
            this.label3.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(442, 37);
            this.label3.TabIndex = 84;
            this.label3.Text = "Do not include a file extension";
            // 
            // GetCloudSensorIILogFilename
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(19F, 37F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(914, 409);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.filename);
            this.Controls.Add(this.CloseBtn);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(7);
            this.Name = "GetCloudSensorIILogFilename";
            this.Text = "CloudSensorII Log Filename";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.GetCloudSensorIILogFilename_cs_FormClosing);
            this.Load += new System.EventHandler(this.GetCloudSensorIILogFilename_cs_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button CloseBtn;
        private System.Windows.Forms.TextBox filename;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}