﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
// added for single instance
using System.Threading;
using System.ComponentModel;
using System.Runtime.InteropServices;


namespace mySQMPLUSTCPIPLOGGER
{
    static class Program
    {
        // GUId of mySQMPLUSTCPIPLOGGER
        static Mutex mutex = new Mutex(true, "{09319214-9be3-4859-a607-ffb3031f39f9}");

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            if (mutex.WaitOne(TimeSpan.Zero, true))
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new mySQMPLUSTCPIPLOGGER());
                mutex.ReleaseMutex();
            }
            else
            {
                MessageBox.Show("Only one instance of mySQMPLUSTCPIPLOGGER can be run at a time.", "mySQMPLUSTCPIPLOGGER", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            }

            // Application.EnableVisualStyles();
            // Application.SetCompatibleTextRenderingDefault(false);
            // Application.Run(new mySQMPLUSTCPIPLOGGER());
        }
    }
}
