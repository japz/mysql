﻿namespace mySQMPLUSTCPIPLOGGER
{
    partial class mySQMPLUSTCPIPLOGGER
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series5 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series6 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(mySQMPLUSTCPIPLOGGER));
            this.label1 = new System.Windows.Forms.Label();
            this.Exitbtn = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.exitMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.settingsMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.alertPopupWhenRainingMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.disableAlertPopoupMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.enableAlertPopupMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.forceExitMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.luxValuesMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resetLogfilesPathMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.setCloudSensorIILogfilenameMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.automate1m = new System.Windows.Forms.RadioButton();
            this.automate5m = new System.Windows.Forms.RadioButton();
            this.automate10m = new System.Windows.Forms.RadioButton();
            this.automategrpbox = new System.Windows.Forms.GroupBox();
            this.loggingstartstopbtn = new System.Windows.Forms.Button();
            this.automate30s = new System.Windows.Forms.RadioButton();
            this.automate30m = new System.Windows.Forms.RadioButton();
            this.automate15m = new System.Windows.Forms.RadioButton();
            this.intervaltimer = new System.Windows.Forms.Timer(this.components);
            this.comportspeedlabel = new System.Windows.Forms.Label();
            this.ClearStatusMsgTimer = new System.Windows.Forms.Timer(this.components);
            this.maintabcontrol = new System.Windows.Forms.TabControl();
            this.maintab = new System.Windows.Forms.TabPage();
            this.sqmluxchart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.temptab = new System.Windows.Forms.TabPage();
            this.tempchart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.settingtab = new System.Windows.Forms.TabPage();
            this.Daylightconditiongrp = new System.Windows.Forms.GroupBox();
            this.dayLighttxtbox = new System.Windows.Forms.TextBox();
            this.dayVeryLighttxtbox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.dayDarklbl = new System.Windows.Forms.Label();
            this.skyconditiongrp = new System.Windows.Forms.GroupBox();
            this.cloudCloudytxtbox = new System.Windows.Forms.TextBox();
            this.cloudVeryCloudytxtbox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.windconditiongroup = new System.Windows.Forms.GroupBox();
            this.windWindytxtbox = new System.Windows.Forms.TextBox();
            this.windVeryWindytxtbox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.loggingtab = new System.Windows.Forms.TabPage();
            this.fetchdatalbl = new System.Windows.Forms.Label();
            this.logstatusvaluelbl = new System.Windows.Forms.Label();
            this.logstatuslbl = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.LogErrorsChkBox = new System.Windows.Forms.CheckBox();
            this.cloudsensor2filenametxtbox = new System.Windows.Forms.TextBox();
            this.csiifilenamelbl = new System.Windows.Forms.Label();
            this.CloudSensorIILogEnablechkbox = new System.Windows.Forms.CheckBox();
            this.LogValuesChkBox = new System.Windows.Forms.CheckBox();
            this.connectiontab = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.ServerPort = new System.Windows.Forms.TextBox();
            this.ServerIpAddress = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.statustxtbox = new System.Windows.Forms.TextBox();
            this.getallbtn = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.automategrpbox.SuspendLayout();
            this.maintabcontrol.SuspendLayout();
            this.maintab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sqmluxchart)).BeginInit();
            this.temptab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tempchart)).BeginInit();
            this.settingtab.SuspendLayout();
            this.Daylightconditiongrp.SuspendLayout();
            this.skyconditiongrp.SuspendLayout();
            this.windconditiongroup.SuspendLayout();
            this.loggingtab.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.connectiontab.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 64);
            this.label1.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(179, 39);
            this.label1.TabIndex = 8;
            this.label1.Text = "IP Address";
            // 
            // Exitbtn
            // 
            this.Exitbtn.Location = new System.Drawing.Point(1274, 794);
            this.Exitbtn.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.Exitbtn.Name = "Exitbtn";
            this.Exitbtn.Size = new System.Drawing.Size(250, 68);
            this.Exitbtn.TabIndex = 9;
            this.Exitbtn.Text = "Exit";
            this.Exitbtn.UseVisualStyleBackColor = true;
            this.Exitbtn.Click += new System.EventHandler(this.Exitbtn_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitMenu,
            this.settingsMenu,
            this.aboutMenu});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(19, 5, 0, 5);
            this.menuStrip1.Size = new System.Drawing.Size(1546, 62);
            this.menuStrip1.TabIndex = 49;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // exitMenu
            // 
            this.exitMenu.Name = "exitMenu";
            this.exitMenu.Size = new System.Drawing.Size(88, 52);
            this.exitMenu.Text = "&Exit";
            this.exitMenu.Click += new System.EventHandler(this.exitMenu_Click);
            // 
            // settingsMenu
            // 
            this.settingsMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.alertPopupWhenRainingMenuItem,
            this.forceExitMenuItem,
            this.luxValuesMenuItem,
            this.resetLogfilesPathMenuItem,
            this.setCloudSensorIILogfilenameMenuItem});
            this.settingsMenu.Name = "settingsMenu";
            this.settingsMenu.Size = new System.Drawing.Size(159, 52);
            this.settingsMenu.Text = "Settings";
            // 
            // alertPopupWhenRainingMenuItem
            // 
            this.alertPopupWhenRainingMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.disableAlertPopoupMenuItem,
            this.enableAlertPopupMenuItem});
            this.alertPopupWhenRainingMenuItem.Name = "alertPopupWhenRainingMenuItem";
            this.alertPopupWhenRainingMenuItem.Size = new System.Drawing.Size(633, 54);
            this.alertPopupWhenRainingMenuItem.Text = "Alert Popup when raining";
            // 
            // disableAlertPopoupMenuItem
            // 
            this.disableAlertPopoupMenuItem.Name = "disableAlertPopoupMenuItem";
            this.disableAlertPopoupMenuItem.Size = new System.Drawing.Size(264, 54);
            this.disableAlertPopoupMenuItem.Text = "Disable";
            this.disableAlertPopoupMenuItem.Click += new System.EventHandler(this.disableAlertPopUpMenuItem_Click);
            // 
            // enableAlertPopupMenuItem
            // 
            this.enableAlertPopupMenuItem.Name = "enableAlertPopupMenuItem";
            this.enableAlertPopupMenuItem.Size = new System.Drawing.Size(264, 54);
            this.enableAlertPopupMenuItem.Text = "Enable";
            this.enableAlertPopupMenuItem.Click += new System.EventHandler(this.enableAlertPopUpMenuItem_Click);
            // 
            // forceExitMenuItem
            // 
            this.forceExitMenuItem.Name = "forceExitMenuItem";
            this.forceExitMenuItem.Size = new System.Drawing.Size(633, 54);
            this.forceExitMenuItem.Text = "Force Exit";
            this.forceExitMenuItem.Click += new System.EventHandler(this.forceExitMenuItem_Click);
            // 
            // luxValuesMenuItem
            // 
            this.luxValuesMenuItem.Name = "luxValuesMenuItem";
            this.luxValuesMenuItem.Size = new System.Drawing.Size(633, 54);
            this.luxValuesMenuItem.Text = "Lux Values";
            this.luxValuesMenuItem.Click += new System.EventHandler(this.luxValuesMenuItem_Click);
            // 
            // resetLogfilesPathMenuItem
            // 
            this.resetLogfilesPathMenuItem.Name = "resetLogfilesPathMenuItem";
            this.resetLogfilesPathMenuItem.Size = new System.Drawing.Size(633, 54);
            this.resetLogfilesPathMenuItem.Text = "Reset Logfiles path";
            this.resetLogfilesPathMenuItem.Click += new System.EventHandler(this.resetLogfilesPathMenuItem_Click);
            // 
            // setCloudSensorIILogfilenameMenuItem
            // 
            this.setCloudSensorIILogfilenameMenuItem.Name = "setCloudSensorIILogfilenameMenuItem";
            this.setCloudSensorIILogfilenameMenuItem.Size = new System.Drawing.Size(633, 54);
            this.setCloudSensorIILogfilenameMenuItem.Text = "Set CloudSensorII Logfilename";
            this.setCloudSensorIILogfilenameMenuItem.Click += new System.EventHandler(this.setCloudSensorIILogfilenameMenuItem_Click);
            // 
            // aboutMenu
            // 
            this.aboutMenu.Name = "aboutMenu";
            this.aboutMenu.Size = new System.Drawing.Size(129, 52);
            this.aboutMenu.Text = "&About";
            this.aboutMenu.Click += new System.EventHandler(this.aboutMenu_Click);
            // 
            // automate1m
            // 
            this.automate1m.AutoSize = true;
            this.automate1m.Location = new System.Drawing.Point(215, 60);
            this.automate1m.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.automate1m.Name = "automate1m";
            this.automate1m.Size = new System.Drawing.Size(111, 43);
            this.automate1m.TabIndex = 71;
            this.automate1m.Text = "1m";
            this.automate1m.UseVisualStyleBackColor = true;
            this.automate1m.CheckedChanged += new System.EventHandler(this.automate1m_CheckedChanged);
            // 
            // automate5m
            // 
            this.automate5m.AutoSize = true;
            this.automate5m.Location = new System.Drawing.Point(415, 60);
            this.automate5m.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.automate5m.Name = "automate5m";
            this.automate5m.Size = new System.Drawing.Size(111, 43);
            this.automate5m.TabIndex = 72;
            this.automate5m.Text = "5m";
            this.automate5m.UseVisualStyleBackColor = true;
            this.automate5m.CheckedChanged += new System.EventHandler(this.automate5m_CheckedChanged);
            // 
            // automate10m
            // 
            this.automate10m.AutoSize = true;
            this.automate10m.Location = new System.Drawing.Point(15, 130);
            this.automate10m.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.automate10m.Name = "automate10m";
            this.automate10m.Size = new System.Drawing.Size(131, 43);
            this.automate10m.TabIndex = 73;
            this.automate10m.Text = "10m";
            this.automate10m.UseVisualStyleBackColor = true;
            this.automate10m.CheckedChanged += new System.EventHandler(this.automate10m_CheckedChanged);
            // 
            // automategrpbox
            // 
            this.automategrpbox.Controls.Add(this.loggingstartstopbtn);
            this.automategrpbox.Controls.Add(this.automate30s);
            this.automategrpbox.Controls.Add(this.automate30m);
            this.automategrpbox.Controls.Add(this.automate15m);
            this.automategrpbox.Controls.Add(this.automate10m);
            this.automategrpbox.Controls.Add(this.automate5m);
            this.automategrpbox.Controls.Add(this.automate1m);
            this.automategrpbox.Location = new System.Drawing.Point(10, 20);
            this.automategrpbox.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.automategrpbox.Name = "automategrpbox";
            this.automategrpbox.Padding = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.automategrpbox.Size = new System.Drawing.Size(674, 290);
            this.automategrpbox.TabIndex = 74;
            this.automategrpbox.TabStop = false;
            this.automategrpbox.Text = "Log Data Interval";
            // 
            // loggingstartstopbtn
            // 
            this.loggingstartstopbtn.Location = new System.Drawing.Point(15, 200);
            this.loggingstartstopbtn.Name = "loggingstartstopbtn";
            this.loggingstartstopbtn.Size = new System.Drawing.Size(250, 68);
            this.loggingstartstopbtn.TabIndex = 113;
            this.loggingstartstopbtn.Text = "Start";
            this.loggingstartstopbtn.UseVisualStyleBackColor = true;
            this.loggingstartstopbtn.Click += new System.EventHandler(this.loggingstartstopbtn_Click);
            // 
            // automate30s
            // 
            this.automate30s.AutoSize = true;
            this.automate30s.Location = new System.Drawing.Point(15, 60);
            this.automate30s.Name = "automate30s";
            this.automate30s.Size = new System.Drawing.Size(117, 43);
            this.automate30s.TabIndex = 78;
            this.automate30s.Text = "30s";
            this.automate30s.UseVisualStyleBackColor = true;
            this.automate30s.CheckedChanged += new System.EventHandler(this.automate30s_CheckedChanged);
            // 
            // automate30m
            // 
            this.automate30m.AutoSize = true;
            this.automate30m.Location = new System.Drawing.Point(415, 130);
            this.automate30m.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.automate30m.Name = "automate30m";
            this.automate30m.Size = new System.Drawing.Size(131, 43);
            this.automate30m.TabIndex = 76;
            this.automate30m.Text = "30m";
            this.automate30m.UseVisualStyleBackColor = true;
            this.automate30m.CheckedChanged += new System.EventHandler(this.automate30m_CheckedChanged);
            // 
            // automate15m
            // 
            this.automate15m.AutoSize = true;
            this.automate15m.Location = new System.Drawing.Point(215, 130);
            this.automate15m.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.automate15m.Name = "automate15m";
            this.automate15m.Size = new System.Drawing.Size(131, 43);
            this.automate15m.TabIndex = 75;
            this.automate15m.Text = "15m";
            this.automate15m.UseVisualStyleBackColor = true;
            this.automate15m.CheckedChanged += new System.EventHandler(this.automate15m_CheckedChanged);
            // 
            // intervaltimer
            // 
            this.intervaltimer.Tick += new System.EventHandler(this.intervaltimer_Tick);
            // 
            // comportspeedlabel
            // 
            this.comportspeedlabel.AutoSize = true;
            this.comportspeedlabel.Location = new System.Drawing.Point(13, 152);
            this.comportspeedlabel.Margin = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.comportspeedlabel.Name = "comportspeedlabel";
            this.comportspeedlabel.Size = new System.Drawing.Size(80, 39);
            this.comportspeedlabel.TabIndex = 75;
            this.comportspeedlabel.Text = "Port";
            // 
            // ClearStatusMsgTimer
            // 
            this.ClearStatusMsgTimer.Interval = 3000;
            this.ClearStatusMsgTimer.Tick += new System.EventHandler(this.ClearStatusMsgTimer_Tick);
            // 
            // maintabcontrol
            // 
            this.maintabcontrol.Controls.Add(this.maintab);
            this.maintabcontrol.Controls.Add(this.temptab);
            this.maintabcontrol.Controls.Add(this.settingtab);
            this.maintabcontrol.Controls.Add(this.loggingtab);
            this.maintabcontrol.Controls.Add(this.connectiontab);
            this.maintabcontrol.Font = new System.Drawing.Font("Lucida Sans Unicode", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maintabcontrol.Location = new System.Drawing.Point(12, 65);
            this.maintabcontrol.Name = "maintabcontrol";
            this.maintabcontrol.SelectedIndex = 0;
            this.maintabcontrol.Size = new System.Drawing.Size(1524, 630);
            this.maintabcontrol.TabIndex = 146;
            // 
            // maintab
            // 
            this.maintab.Controls.Add(this.sqmluxchart);
            this.maintab.Location = new System.Drawing.Point(12, 60);
            this.maintab.Name = "maintab";
            this.maintab.Padding = new System.Windows.Forms.Padding(3);
            this.maintab.Size = new System.Drawing.Size(1500, 558);
            this.maintab.TabIndex = 0;
            this.maintab.Text = "Main";
            this.maintab.UseVisualStyleBackColor = true;
            // 
            // sqmluxchart
            // 
            chartArea1.AxisX.IsLabelAutoFit = false;
            chartArea1.AxisX.LabelStyle.Font = new System.Drawing.Font("Arial", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea1.AxisX.TitleFont = new System.Drawing.Font("Arial", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea1.AxisX2.IsLabelAutoFit = false;
            chartArea1.AxisX2.LabelStyle.Font = new System.Drawing.Font("Arial", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea1.AxisY.IsLabelAutoFit = false;
            chartArea1.AxisY.LabelStyle.Font = new System.Drawing.Font("Arial", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea1.AxisY.TitleFont = new System.Drawing.Font("Arial", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea1.AxisY2.IsLabelAutoFit = false;
            chartArea1.AxisY2.LabelStyle.Font = new System.Drawing.Font("Arial", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea1.Name = "ChartArea1";
            this.sqmluxchart.ChartAreas.Add(chartArea1);
            legend1.AutoFitMinFontSize = 6;
            legend1.Font = new System.Drawing.Font("Arial", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            legend1.IsTextAutoFit = false;
            legend1.Name = "Legend1";
            this.sqmluxchart.Legends.Add(legend1);
            this.sqmluxchart.Location = new System.Drawing.Point(10, 10);
            this.sqmluxchart.Name = "sqmluxchart";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series1.Font = new System.Drawing.Font("Arial", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            series1.Legend = "Legend1";
            series1.Name = "SQM";
            series1.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Time;
            series1.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Double;
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series2.Font = new System.Drawing.Font("Arial", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            series2.Legend = "Legend1";
            series2.Name = "LUX";
            series2.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Time;
            series2.YAxisType = System.Windows.Forms.DataVisualization.Charting.AxisType.Secondary;
            series2.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Double;
            this.sqmluxchart.Series.Add(series1);
            this.sqmluxchart.Series.Add(series2);
            this.sqmluxchart.Size = new System.Drawing.Size(1465, 526);
            this.sqmluxchart.TabIndex = 147;
            this.sqmluxchart.Text = "chart1";
            // 
            // temptab
            // 
            this.temptab.Controls.Add(this.tempchart);
            this.temptab.Location = new System.Drawing.Point(12, 60);
            this.temptab.Name = "temptab";
            this.temptab.Size = new System.Drawing.Size(1500, 558);
            this.temptab.TabIndex = 5;
            this.temptab.Text = "Temperatures";
            this.temptab.UseVisualStyleBackColor = true;
            // 
            // tempchart
            // 
            chartArea2.AxisX.IsLabelAutoFit = false;
            chartArea2.AxisX.LabelStyle.Font = new System.Drawing.Font("Arial", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea2.AxisX.TitleFont = new System.Drawing.Font("Arial", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea2.AxisY.IsLabelAutoFit = false;
            chartArea2.AxisY.LabelStyle.Font = new System.Drawing.Font("Arial", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea2.AxisY.TitleFont = new System.Drawing.Font("Arial", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea2.Name = "ChartArea1";
            this.tempchart.ChartAreas.Add(chartArea2);
            legend2.AutoFitMinFontSize = 6;
            legend2.Font = new System.Drawing.Font("Arial", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            legend2.IsTextAutoFit = false;
            legend2.Name = "Legend1";
            this.tempchart.Legends.Add(legend2);
            this.tempchart.Location = new System.Drawing.Point(10, 10);
            this.tempchart.Name = "tempchart";
            series3.ChartArea = "ChartArea1";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series3.Legend = "Legend1";
            series3.Name = "Ambient";
            series3.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Time;
            series3.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Double;
            series4.ChartArea = "ChartArea1";
            series4.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series4.Legend = "Legend1";
            series4.Name = "Dewpoint";
            series4.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Time;
            series4.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Double;
            series5.ChartArea = "ChartArea1";
            series5.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series5.Legend = "Legend1";
            series5.Name = "SkyAmbient";
            series5.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Time;
            series5.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Double;
            series6.ChartArea = "ChartArea1";
            series6.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series6.Legend = "Legend1";
            series6.Name = "SkyObject";
            series6.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Time;
            series6.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Double;
            this.tempchart.Series.Add(series3);
            this.tempchart.Series.Add(series4);
            this.tempchart.Series.Add(series5);
            this.tempchart.Series.Add(series6);
            this.tempchart.Size = new System.Drawing.Size(1463, 529);
            this.tempchart.TabIndex = 149;
            this.tempchart.Text = "chart1";
            // 
            // settingtab
            // 
            this.settingtab.Controls.Add(this.Daylightconditiongrp);
            this.settingtab.Controls.Add(this.skyconditiongrp);
            this.settingtab.Controls.Add(this.windconditiongroup);
            this.settingtab.Location = new System.Drawing.Point(12, 60);
            this.settingtab.Name = "settingtab";
            this.settingtab.Size = new System.Drawing.Size(1500, 558);
            this.settingtab.TabIndex = 6;
            this.settingtab.Text = "Settings";
            this.settingtab.UseVisualStyleBackColor = true;
            // 
            // Daylightconditiongrp
            // 
            this.Daylightconditiongrp.Controls.Add(this.dayLighttxtbox);
            this.Daylightconditiongrp.Controls.Add(this.dayVeryLighttxtbox);
            this.Daylightconditiongrp.Controls.Add(this.label9);
            this.Daylightconditiongrp.Controls.Add(this.label10);
            this.Daylightconditiongrp.Controls.Add(this.dayDarklbl);
            this.Daylightconditiongrp.Location = new System.Drawing.Point(20, 278);
            this.Daylightconditiongrp.Name = "Daylightconditiongrp";
            this.Daylightconditiongrp.Size = new System.Drawing.Size(576, 259);
            this.Daylightconditiongrp.TabIndex = 5;
            this.Daylightconditiongrp.TabStop = false;
            this.Daylightconditiongrp.Text = "Daylight Condition";
            // 
            // dayLighttxtbox
            // 
            this.dayLighttxtbox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dayLighttxtbox.Location = new System.Drawing.Point(395, 115);
            this.dayLighttxtbox.Name = "dayLighttxtbox";
            this.dayLighttxtbox.Size = new System.Drawing.Size(141, 57);
            this.dayLighttxtbox.TabIndex = 4;
            this.dayLighttxtbox.Text = "10";
            this.dayLighttxtbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dayLighttxtbox_KeyPress);
            // 
            // dayVeryLighttxtbox
            // 
            this.dayVeryLighttxtbox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dayVeryLighttxtbox.Location = new System.Drawing.Point(395, 50);
            this.dayVeryLighttxtbox.Name = "dayVeryLighttxtbox";
            this.dayVeryLighttxtbox.Size = new System.Drawing.Size(141, 57);
            this.dayVeryLighttxtbox.TabIndex = 3;
            this.dayVeryLighttxtbox.Text = "100";
            this.dayVeryLighttxtbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dayVeryLighttxtbox_KeyPress);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 50);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(339, 39);
            this.label9.TabIndex = 2;
            this.label9.Text = "dayVeryLight [3] >= \r\n";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 115);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(260, 39);
            this.label10.TabIndex = 1;
            this.label10.Text = "dayLight [2] >=\r\n";
            // 
            // dayDarklbl
            // 
            this.dayDarklbl.AutoSize = true;
            this.dayDarklbl.Location = new System.Drawing.Point(6, 185);
            this.dayDarklbl.Name = "dayDarklbl";
            this.dayDarklbl.Size = new System.Drawing.Size(374, 39);
            this.dayDarklbl.TabIndex = 0;
            this.dayDarklbl.Text = "dayDark [1] < dayLight";
            // 
            // skyconditiongrp
            // 
            this.skyconditiongrp.Controls.Add(this.cloudCloudytxtbox);
            this.skyconditiongrp.Controls.Add(this.cloudVeryCloudytxtbox);
            this.skyconditiongrp.Controls.Add(this.label8);
            this.skyconditiongrp.Controls.Add(this.label7);
            this.skyconditiongrp.Controls.Add(this.label6);
            this.skyconditiongrp.Location = new System.Drawing.Point(710, 20);
            this.skyconditiongrp.Name = "skyconditiongrp";
            this.skyconditiongrp.Size = new System.Drawing.Size(731, 247);
            this.skyconditiongrp.TabIndex = 1;
            this.skyconditiongrp.TabStop = false;
            this.skyconditiongrp.Text = "Cloud State";
            // 
            // cloudCloudytxtbox
            // 
            this.cloudCloudytxtbox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.cloudCloudytxtbox.Location = new System.Drawing.Point(510, 115);
            this.cloudCloudytxtbox.Name = "cloudCloudytxtbox";
            this.cloudCloudytxtbox.Size = new System.Drawing.Size(141, 57);
            this.cloudCloudytxtbox.TabIndex = 6;
            this.cloudCloudytxtbox.Text = "34.0";
            this.cloudCloudytxtbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cloudCloudytxtbox_KeyPress);
            // 
            // cloudVeryCloudytxtbox
            // 
            this.cloudVeryCloudytxtbox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.cloudVeryCloudytxtbox.Location = new System.Drawing.Point(510, 50);
            this.cloudVeryCloudytxtbox.Name = "cloudVeryCloudytxtbox";
            this.cloudVeryCloudytxtbox.Size = new System.Drawing.Size(141, 57);
            this.cloudVeryCloudytxtbox.TabIndex = 5;
            this.cloudVeryCloudytxtbox.Text = "59.9";
            this.cloudVeryCloudytxtbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cloudVeryCloudytxtbox_KeyPress);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(15, 185);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(470, 39);
            this.label8.TabIndex = 2;
            this.label8.Text = "cloudClear [1] < cloudCloudy";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(15, 115);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(330, 39);
            this.label7.TabIndex = 1;
            this.label7.Text = "cloudCloudy [2] >= ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(15, 50);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(399, 39);
            this.label6.TabIndex = 0;
            this.label6.Text = "cloudVeryCloudy [3] >= ";
            // 
            // windconditiongroup
            // 
            this.windconditiongroup.Controls.Add(this.windWindytxtbox);
            this.windconditiongroup.Controls.Add(this.windVeryWindytxtbox);
            this.windconditiongroup.Controls.Add(this.label5);
            this.windconditiongroup.Controls.Add(this.label4);
            this.windconditiongroup.Controls.Add(this.label2);
            this.windconditiongroup.Location = new System.Drawing.Point(20, 20);
            this.windconditiongroup.Name = "windconditiongroup";
            this.windconditiongroup.Size = new System.Drawing.Size(576, 247);
            this.windconditiongroup.TabIndex = 0;
            this.windconditiongroup.TabStop = false;
            this.windconditiongroup.Text = "Wind Condition";
            // 
            // windWindytxtbox
            // 
            this.windWindytxtbox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.windWindytxtbox.Location = new System.Drawing.Point(395, 115);
            this.windWindytxtbox.Name = "windWindytxtbox";
            this.windWindytxtbox.Size = new System.Drawing.Size(141, 57);
            this.windWindytxtbox.TabIndex = 4;
            this.windWindytxtbox.Text = "5.0";
            this.windWindytxtbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.windWindytxtbox_KeyPress);
            // 
            // windVeryWindytxtbox
            // 
            this.windVeryWindytxtbox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.windVeryWindytxtbox.Location = new System.Drawing.Point(395, 50);
            this.windVeryWindytxtbox.Name = "windVeryWindytxtbox";
            this.windVeryWindytxtbox.Size = new System.Drawing.Size(141, 57);
            this.windVeryWindytxtbox.TabIndex = 3;
            this.windVeryWindytxtbox.Text = "15.0";
            this.windVeryWindytxtbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.windVeryWindytxtbox_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 50);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(373, 39);
            this.label5.TabIndex = 2;
            this.label5.Text = "windVeryWindy [3] >= \r\n";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 115);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(294, 39);
            this.label4.TabIndex = 1;
            this.label4.Text = "windWindy [2] >=\r\n";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 185);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(432, 39);
            this.label2.TabIndex = 0;
            this.label2.Text = "windCalm [1] < windWindy";
            // 
            // loggingtab
            // 
            this.loggingtab.Controls.Add(this.fetchdatalbl);
            this.loggingtab.Controls.Add(this.logstatusvaluelbl);
            this.loggingtab.Controls.Add(this.logstatuslbl);
            this.loggingtab.Controls.Add(this.groupBox1);
            this.loggingtab.Controls.Add(this.automategrpbox);
            this.loggingtab.Location = new System.Drawing.Point(12, 60);
            this.loggingtab.Name = "loggingtab";
            this.loggingtab.Size = new System.Drawing.Size(1500, 558);
            this.loggingtab.TabIndex = 3;
            this.loggingtab.Text = "Logging";
            this.loggingtab.UseVisualStyleBackColor = true;
            // 
            // fetchdatalbl
            // 
            this.fetchdatalbl.AutoSize = true;
            this.fetchdatalbl.Location = new System.Drawing.Point(255, 475);
            this.fetchdatalbl.Name = "fetchdatalbl";
            this.fetchdatalbl.Size = new System.Drawing.Size(37, 39);
            this.fetchdatalbl.TabIndex = 112;
            this.fetchdatalbl.Text = "..";
            // 
            // logstatusvaluelbl
            // 
            this.logstatusvaluelbl.AutoSize = true;
            this.logstatusvaluelbl.Location = new System.Drawing.Point(255, 415);
            this.logstatusvaluelbl.Name = "logstatusvaluelbl";
            this.logstatusvaluelbl.Size = new System.Drawing.Size(144, 39);
            this.logstatusvaluelbl.TabIndex = 111;
            this.logstatusvaluelbl.Text = "Stopped";
            // 
            // logstatuslbl
            // 
            this.logstatuslbl.AutoSize = true;
            this.logstatuslbl.Location = new System.Drawing.Point(18, 415);
            this.logstatuslbl.Name = "logstatuslbl";
            this.logstatuslbl.Size = new System.Drawing.Size(198, 39);
            this.logstatuslbl.TabIndex = 110;
            this.logstatuslbl.Text = "Log status: ";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.LogErrorsChkBox);
            this.groupBox1.Controls.Add(this.cloudsensor2filenametxtbox);
            this.groupBox1.Controls.Add(this.csiifilenamelbl);
            this.groupBox1.Controls.Add(this.CloudSensorIILogEnablechkbox);
            this.groupBox1.Controls.Add(this.LogValuesChkBox);
            this.groupBox1.Location = new System.Drawing.Point(718, 20);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(752, 512);
            this.groupBox1.TabIndex = 109;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Logging";
            // 
            // LogErrorsChkBox
            // 
            this.LogErrorsChkBox.AutoSize = true;
            this.LogErrorsChkBox.Checked = global::mySQMPLUSTCPIPLOGGER.Properties.Settings.Default.ErrorLoggingEnabled;
            this.LogErrorsChkBox.DataBindings.Add(new System.Windows.Forms.Binding("Checked", global::mySQMPLUSTCPIPLOGGER.Properties.Settings.Default, "ErrorLoggingEnabled", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.LogErrorsChkBox.Location = new System.Drawing.Point(20, 60);
            this.LogErrorsChkBox.Margin = new System.Windows.Forms.Padding(7);
            this.LogErrorsChkBox.Name = "LogErrorsChkBox";
            this.LogErrorsChkBox.Size = new System.Drawing.Size(223, 43);
            this.LogErrorsChkBox.TabIndex = 104;
            this.LogErrorsChkBox.Text = "Log errors";
            this.LogErrorsChkBox.UseVisualStyleBackColor = true;
            this.LogErrorsChkBox.CheckedChanged += new System.EventHandler(this.LogErrorsChkBox_CheckedChanged);
            // 
            // cloudsensor2filenametxtbox
            // 
            this.cloudsensor2filenametxtbox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.cloudsensor2filenametxtbox.DataBindings.Add(new System.Windows.Forms.Binding("Text", global::mySQMPLUSTCPIPLOGGER.Properties.Settings.Default, "CloudSensorIILogFilename", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.cloudsensor2filenametxtbox.Location = new System.Drawing.Point(20, 326);
            this.cloudsensor2filenametxtbox.Name = "cloudsensor2filenametxtbox";
            this.cloudsensor2filenametxtbox.Size = new System.Drawing.Size(623, 57);
            this.cloudsensor2filenametxtbox.TabIndex = 107;
            this.cloudsensor2filenametxtbox.Text = global::mySQMPLUSTCPIPLOGGER.Properties.Settings.Default.CloudSensorIILogFilename;
            this.cloudsensor2filenametxtbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cloudsensor2filenametxtbox_KeyPress);
            // 
            // csiifilenamelbl
            // 
            this.csiifilenamelbl.AutoSize = true;
            this.csiifilenamelbl.Location = new System.Drawing.Point(20, 273);
            this.csiifilenamelbl.Name = "csiifilenamelbl";
            this.csiifilenamelbl.Size = new System.Drawing.Size(223, 39);
            this.csiifilenamelbl.TabIndex = 108;
            this.csiifilenamelbl.Text = "CSII Filename";
            // 
            // CloudSensorIILogEnablechkbox
            // 
            this.CloudSensorIILogEnablechkbox.AutoSize = true;
            this.CloudSensorIILogEnablechkbox.Checked = global::mySQMPLUSTCPIPLOGGER.Properties.Settings.Default.CloudSensorIILogFileFormat;
            this.CloudSensorIILogEnablechkbox.DataBindings.Add(new System.Windows.Forms.Binding("Checked", global::mySQMPLUSTCPIPLOGGER.Properties.Settings.Default, "CloudSensorIILogFileFormat", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.CloudSensorIILogEnablechkbox.Location = new System.Drawing.Point(20, 200);
            this.CloudSensorIILogEnablechkbox.Margin = new System.Windows.Forms.Padding(7);
            this.CloudSensorIILogEnablechkbox.Name = "CloudSensorIILogEnablechkbox";
            this.CloudSensorIILogEnablechkbox.Size = new System.Drawing.Size(250, 43);
            this.CloudSensorIILogEnablechkbox.TabIndex = 77;
            this.CloudSensorIILogEnablechkbox.Text = "Log CSII File";
            this.CloudSensorIILogEnablechkbox.UseVisualStyleBackColor = true;
            // 
            // LogValuesChkBox
            // 
            this.LogValuesChkBox.AutoSize = true;
            this.LogValuesChkBox.Checked = global::mySQMPLUSTCPIPLOGGER.Properties.Settings.Default.DataLogFileEnabled;
            this.LogValuesChkBox.DataBindings.Add(new System.Windows.Forms.Binding("Checked", global::mySQMPLUSTCPIPLOGGER.Properties.Settings.Default, "DataLogFileEnabled", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.LogValuesChkBox.Location = new System.Drawing.Point(20, 130);
            this.LogValuesChkBox.Margin = new System.Windows.Forms.Padding(7);
            this.LogValuesChkBox.Name = "LogValuesChkBox";
            this.LogValuesChkBox.Size = new System.Drawing.Size(232, 43);
            this.LogValuesChkBox.TabIndex = 105;
            this.LogValuesChkBox.Text = "Log Values";
            this.LogValuesChkBox.UseVisualStyleBackColor = true;
            this.LogValuesChkBox.CheckedChanged += new System.EventHandler(this.LogValuesChkBox_CheckedChanged);
            // 
            // connectiontab
            // 
            this.connectiontab.BackColor = System.Drawing.Color.Transparent;
            this.connectiontab.Controls.Add(this.groupBox2);
            this.connectiontab.ForeColor = System.Drawing.SystemColors.ControlText;
            this.connectiontab.Location = new System.Drawing.Point(12, 60);
            this.connectiontab.Name = "connectiontab";
            this.connectiontab.Size = new System.Drawing.Size(1500, 558);
            this.connectiontab.TabIndex = 4;
            this.connectiontab.Text = "Connection";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.ServerPort);
            this.groupBox2.Controls.Add(this.comportspeedlabel);
            this.groupBox2.Controls.Add(this.ServerIpAddress);
            this.groupBox2.Location = new System.Drawing.Point(20, 20);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(539, 254);
            this.groupBox2.TabIndex = 137;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Connection";
            // 
            // ServerPort
            // 
            this.ServerPort.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ServerPort.DataBindings.Add(new System.Windows.Forms.Binding("Text", global::mySQMPLUSTCPIPLOGGER.Properties.Settings.Default, "TCPIPPort", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.ServerPort.Location = new System.Drawing.Point(215, 141);
            this.ServerPort.Name = "ServerPort";
            this.ServerPort.ReadOnly = true;
            this.ServerPort.Size = new System.Drawing.Size(284, 57);
            this.ServerPort.TabIndex = 136;
            this.ServerPort.Text = global::mySQMPLUSTCPIPLOGGER.Properties.Settings.Default.TCPIPPort;
            // 
            // ServerIpAddress
            // 
            this.ServerIpAddress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ServerIpAddress.DataBindings.Add(new System.Windows.Forms.Binding("Text", global::mySQMPLUSTCPIPLOGGER.Properties.Settings.Default, "IPAddress", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.ServerIpAddress.Location = new System.Drawing.Point(215, 61);
            this.ServerIpAddress.Name = "ServerIpAddress";
            this.ServerIpAddress.Size = new System.Drawing.Size(284, 57);
            this.ServerIpAddress.TabIndex = 135;
            this.ServerIpAddress.Text = global::mySQMPLUSTCPIPLOGGER.Properties.Settings.Default.IPAddress;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(20, 708);
            this.label3.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(261, 37);
            this.label3.TabIndex = 149;
            this.label3.Text = "Status Messages";
            // 
            // statustxtbox
            // 
            this.statustxtbox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.statustxtbox.Location = new System.Drawing.Point(20, 752);
            this.statustxtbox.Margin = new System.Windows.Forms.Padding(7);
            this.statustxtbox.Name = "statustxtbox";
            this.statustxtbox.ReadOnly = true;
            this.statustxtbox.Size = new System.Drawing.Size(1218, 44);
            this.statustxtbox.TabIndex = 148;
            this.statustxtbox.TextChanged += new System.EventHandler(this.statustxtbox_TextChanged);
            // 
            // getallbtn
            // 
            this.getallbtn.Location = new System.Drawing.Point(1274, 708);
            this.getallbtn.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.getallbtn.Name = "getallbtn";
            this.getallbtn.Size = new System.Drawing.Size(250, 68);
            this.getallbtn.TabIndex = 147;
            this.getallbtn.Text = "Get";
            this.getallbtn.UseVisualStyleBackColor = true;
            this.getallbtn.Click += new System.EventHandler(this.getallbtn_Click);
            // 
            // mySQMPLUSTCPIPLOGGER
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(19F, 37F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1546, 902);
            this.Controls.Add(this.getallbtn);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.statustxtbox);
            this.Controls.Add(this.maintabcontrol);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.Exitbtn);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.Name = "mySQMPLUSTCPIPLOGGER";
            this.Text = "mySQM+ TCP/IP LOGGER (c) R Brown 2020-2021";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.mySQMGPS_FormClosing);
            this.Load += new System.EventHandler(this.mySQMPLUSTCPIPLOGGER_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.mySQMPLUSTCPIPLOGGER_KeyDown);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.automategrpbox.ResumeLayout(false);
            this.automategrpbox.PerformLayout();
            this.maintabcontrol.ResumeLayout(false);
            this.maintab.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.sqmluxchart)).EndInit();
            this.temptab.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tempchart)).EndInit();
            this.settingtab.ResumeLayout(false);
            this.Daylightconditiongrp.ResumeLayout(false);
            this.Daylightconditiongrp.PerformLayout();
            this.skyconditiongrp.ResumeLayout(false);
            this.skyconditiongrp.PerformLayout();
            this.windconditiongroup.ResumeLayout(false);
            this.windconditiongroup.PerformLayout();
            this.loggingtab.ResumeLayout(false);
            this.loggingtab.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.connectiontab.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Exitbtn;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem exitMenu;
        private System.Windows.Forms.ToolStripMenuItem aboutMenu;
        private System.Windows.Forms.RadioButton automate1m;
        private System.Windows.Forms.RadioButton automate5m;
        private System.Windows.Forms.RadioButton automate10m;
        private System.Windows.Forms.GroupBox automategrpbox;
        private System.Windows.Forms.Timer intervaltimer;
        private System.Windows.Forms.ToolStripMenuItem settingsMenu;
        private System.Windows.Forms.ToolStripMenuItem forceExitMenuItem;
        private System.Windows.Forms.Label comportspeedlabel;
        private System.Windows.Forms.RadioButton automate30m;
        private System.Windows.Forms.RadioButton automate15m;
        private System.Windows.Forms.Timer ClearStatusMsgTimer;
        private System.Windows.Forms.ToolStripMenuItem resetLogfilesPathMenuItem;
        private System.Windows.Forms.CheckBox LogErrorsChkBox;
        private System.Windows.Forms.CheckBox LogValuesChkBox;
        private System.Windows.Forms.ToolStripMenuItem alertPopupWhenRainingMenuItem;
        private System.Windows.Forms.ToolStripMenuItem disableAlertPopoupMenuItem;
        private System.Windows.Forms.ToolStripMenuItem enableAlertPopupMenuItem;
        private System.Windows.Forms.ToolStripMenuItem luxValuesMenuItem;
        private System.Windows.Forms.CheckBox CloudSensorIILogEnablechkbox;
        private System.Windows.Forms.ToolStripMenuItem setCloudSensorIILogfilenameMenuItem;
        private System.Windows.Forms.TextBox ServerIpAddress;
        private System.Windows.Forms.TextBox ServerPort;
        private System.Windows.Forms.TabControl maintabcontrol;
        private System.Windows.Forms.TabPage maintab;
        private System.Windows.Forms.TabPage loggingtab;
        private System.Windows.Forms.TabPage connectiontab;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox statustxtbox;
        private System.Windows.Forms.Button getallbtn;
        private System.Windows.Forms.DataVisualization.Charting.Chart sqmluxchart;
        private System.Windows.Forms.RadioButton automate30s;
        private System.Windows.Forms.TabPage temptab;
        private System.Windows.Forms.DataVisualization.Charting.Chart tempchart;
        private System.Windows.Forms.Label csiifilenamelbl;
        private System.Windows.Forms.TextBox cloudsensor2filenametxtbox;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label logstatusvaluelbl;
        private System.Windows.Forms.Label logstatuslbl;
        private System.Windows.Forms.Label fetchdatalbl;
        private System.Windows.Forms.Button loggingstartstopbtn;
        private System.Windows.Forms.TabPage settingtab;
        private System.Windows.Forms.GroupBox skyconditiongrp;
        private System.Windows.Forms.GroupBox windconditiongroup;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox windWindytxtbox;
        private System.Windows.Forms.TextBox windVeryWindytxtbox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox cloudCloudytxtbox;
        private System.Windows.Forms.TextBox cloudVeryCloudytxtbox;
        private System.Windows.Forms.GroupBox Daylightconditiongrp;
        private System.Windows.Forms.TextBox dayLighttxtbox;
        private System.Windows.Forms.TextBox dayVeryLighttxtbox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label dayDarklbl;
    }
}

