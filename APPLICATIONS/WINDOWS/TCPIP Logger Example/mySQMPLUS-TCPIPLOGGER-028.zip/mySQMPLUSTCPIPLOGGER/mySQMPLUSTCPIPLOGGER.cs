﻿using System;
using System.IO.Ports;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;            // for logfile
using System.Media;         // for sound
using System.Windows.Forms.DataVisualization.Charting;
using System.Reflection;
using System.Globalization;
using System.Threading;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization;
using System.Web.Script.Serialization;

// mySQMPLUS TCP/IP LOGGER Windows Application
// Copyright R B Brown, 2020-2021. All Rights Reserved
// Permission is granted for personal and Academic/Educational use only.

// 0.0.28
// Update for new firmware 125+
// Change logging output to only JSON (compatible with LogViewerPlus
// Fix for automate radio buttons (sometimes interval is set incorrectly)

// 0.0.27
// Add additional log messages
// Extract code in getalldatavalues into seperate routines
// Rewrite some of the interval timer code
// Fix for some datalog issues

// 0.0.26
// Fix for not writing datalog and cs2 file

// 0.0.25
// Additional logging information
// Change log filenames (too long)
// Remove 10s/15s updates from logging tab - the data can take longer than 10s to arrive

// 0.0.24
// Fix error in datalog file (rainfall curr day and p======rev hour)
// Fix for logging Pressure in data log file
// Fix for gps being blank in log file
// Fix for datalogfile errors after cloudcover value
// Add /about request and add firmware version to logfile (in place of NotConnected)
// Add raincurrday, rainprevhr, rainprevday to datalog header line
// Add additional error checking around data requests and logging data
// Add additional error checking in the interval timer code
// Add locale handling for all values

// 0.0.23
// Adjustment of DayCondition boundaries

// 0.0.21
// Additional Fixes
// Add settings tab

// 0.0.20
// Fix Raining issue (caused by JSON de-serialization error)
// Fix locale issues for xx,xx which causes problems loading into Excel
// Add rainfall to mySQM+ data logfile

// 0.0.19
// Replace automate check box with Start/Stop logging button
// code changes made to rain flag, wet flag, skystate, wind condition, rain condition, daylight condition

// 0.0.18
// Extra logging to log JSON responses from server and deserialized results
// Fixes for a number of values

// 0.0.17
// Remove Boltwood

// 0.0.16
// Rewrite cloud sensor file code

// 0.0.15
// Add status indicator label for interval timer

// 0.0.14
// Fix for data/time not showing in CSII log file

// 0.0.13
// Add user ability to specify cloud sensor ii filename
// Add socket read timeout values
// Make sure cloud sensor data file is single line and new data overwrites old data

// 0.0.12
// Remove graph button and seperate graph window

// 0.0.11
// Move automate checkbox as it is clipped

// 0.0.10
// Add 15s and 30s to logging interval
// Make SQM/NELM graph larger
// Make Temp Tab and move temp graph to that tab

// 0.0.9
// Change name to mySQMPLUSTCPIPLOGGER

// 0.0.7
// Change pressure to double

// 0.0.6
// Fix bug for CS-II logfile cloudstate

// 0.0.5
// Change logfile to write cloudstate as 0 or 1 instead of CLEAR / CLOUDY

// 0.0.4
// Fix main graph lux showing as 1E etc - change to decimal places

// 0.0.3
// Change Icon

// 0.0.2
// Fix for wrong desktop icon name
// Fix for sqm always being 0
// Fix for no , in datalogfile after windspeed

// 0.0.1 
// Initial release

// GUID 09319214-9be3-4859-a607-ffb3031f39f9

// 001

/* Logfile format
Logfile format
0	Date
1	Time
2	SQM
3	Lux
4	IRAmbient - MLX90614 IR Temp Sensor
5	IRObject
6	Firmware
7	Raining/Not Raining (0/1)
8	RainVoltage
9	NELM
10	bmeTemp - BME280
11	bmeHumidity
12	bmeDew
13	bmePressure
14	gpsdate
15 	gpstime
16	gpslongitude
17	gpslatitude
18	gpssatelittes
19	gpsaltitude
20	skystate - Clear/Partly Cloudy/Cloudy/Unknown (0/1/2/3)
21	Wind speed
22	Wind direction
23  Cloud cover percentage
24  Rainfall current hour
25  Rainfall current day
26  Rainfall previous hour
27  Rainfall previous day 
*/

namespace mySQMPLUSTCPIPLOGGER
{
    public partial class mySQMPLUSTCPIPLOGGER : Form
    {
        public mySQMPLUSTCPIPLOGGER()
        {
            InitializeComponent();
            // insert code here to prevent window resizing
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            // this.MinimizeBox = false;  // do not as user cannot minimize form!!!
        }

        public static Mutex Sermutex = new Mutex();
        static Mutex logmutex = new Mutex(true);    // semaphore lock to manage access to logfile
        private string serverIP;                    // sever ip address as string
        private IPAddress server_ipaddr;            // server ip address
        public int socketreadtimeout;

        public bool automaterunning = false;

        public WebClient client;
        public string myVersion;

        private string CopyrightStr = "© Copyright R Brown 2020-2021. All Rights Reserved." + System.Environment.NewLine + "Permission is granted for personal use only.";
        public string ArduinoFirmwareRev;
        public string Datalogfilename;              // name of data logging file
        public string Errorlogfilename;
        public string CSlogfilename;

        public logfileform logpathfrm;              // logging form to set folder/path
        public GetCloudSensorIILogFilename CloudSensorForm;
        public static bool CSFormActive;

        public bool Raining;
        public double RainVout;

        public bool CSIItestoutput;

        public class aboutgroup
        {
            public string product;
            public string Author;
            public string ver;
        }

        public class temperaturegroup
        {
            // bme280ambient, dewpoint, mlx90614ambient, mlx90614object
            public double ambient;
            public double dewpoint;
            public double skyobject;
            public double skyambient;
        }

        public class weathergroup
        {
            // humidity, pressure, raining, rvout, windspeed, winddirection
            // { "humidity":56.7,"pressure":985.63,"raining":1,"rvout":0.84,"rainhour":0.00,"rainday":0.00,"windspd":26.00,"beaufort":10,"winddir":225 }
            public double humidity;
            public double pressure;
            public int raining;
            public double rvout;
            public float raincurrhr;       // current_rainfall_hourly
            public float raincurrday;        // current_rainfall_daily
            public double windspd;
            public int beaufort;
            public int winddir;
        }

        public class darkskygroup
        {
            // sqm, nelm, lux, skystate, cloudcover
            public double sqm;
            public double nelm;
            public double lux;
            public int skystate;
            public double cloudcover;
        }

        public class gpsgroup
        {
            public string gpsdate;
            public string gpstime;
            public string gpslat;
            public string gpslon;
            public string gpssat;
            public string gpsalt;
            public string gpsfix;
        }

        // { "rainhour":xx.x,"rainphour":xx.x, "rainday":xx.x,"rainpday":xx.x }";
        public class rainfallgroup
        {
            public float raincurrhr;            // the current cummulative hourly rainfall (in mm)
            public float raincurrday;           // the current cummulative daily rainfall (starts from 9am) (in mm)
            public float rainprevhr;            // the previous hours cummulative hourly rainfall (in mm)
            public float rainprevday;           // the previos daily cummulative hourly rainfall (in mm)
        }

        public const int SKYCLEAR = 0;
        public const int SKYCLOUDY = 1;

        public int sqmluxchartobjectplotcount;
        public int tempchartobjectplotcount;
        public int numberofpointplots = 9;
        public int windspeedchartplotcount;
        public int bme280humiditychartplotcount;
        public int bme280pressurechartplotcount;

        public CultureInfo thisCulture;
        public CultureInfo thisICCulture;
        public CultureInfo us_english;

        private DateTime lastTime;                          // for logging
        private DateTime lastUpdateCSII;
        private DateTime lastUpdatedata;

        public temperaturegroup mytemperaturegroup;
        public weathergroup myweathergroup;
        public darkskygroup mydarkskygroup;
        public gpsgroup mygpsgroup;
        public rainfallgroup myrainfallgroup;
        public aboutgroup myaboutgrp;

        public double windVeryWindy;
        public double windWindy;
        public double cloudVeryCloudy;
        public double cloudCloudy;
        public double dayVeryLight;
        public double dayLight;
        public double dayDark;

        private void Badresponse()
        {
            string funcname = "Bad response: ";

            LogMessageToErrorFile(funcname + "START======");
            LogMessageToErrorFile("There was an invalid response from the controller. ");
            statustxtbox.Text = "There was an invalid response from the controller.";
            statustxtbox.Update();
            stoplogging();
            LogMessageToErrorFile(funcname + "END======");
        }

        private void Nullresponse()
        {
            string funcname = "Null response: ";
            LogMessageToErrorFile(funcname + "START======");
            statustxtbox.Text = "There was no response from the controller. The application has disconnected from the server and closed the connection.\nYou could try re-connecting?";
            statustxtbox.Update();
            stoplogging();
            LogMessageToErrorFile(funcname + "END======");
        }

        // Write data to the error logfile
        public void LogMessageToErrorFile(string DataString)
        {
            string bufferdata;
            DateTime localDate = DateTime.Now;
            if (Properties.Settings.Default.ErrorLoggingEnabled == true)
            {
                //bufferdata = localDate.ToString("dddd , MMM dd yyyy,hh:mm:ss") + "  " + DataString + Environment.NewLine;
                bufferdata = localDate.ToString("yyyy/MM/dd,hh:mm:ss") + "  " + DataString + Environment.NewLine;
                try
                {
                    File.AppendAllText(Errorlogfilename, bufferdata);
                }
                catch (Exception)
                {
                    MessageBox.Show("Error writing to error logfile: " + System.Environment.NewLine + DataString, "mySQM+ TCP/IP LOGGER", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    if (LogErrorsChkBox.Checked == true)
                    {
                        LogErrorsChkBox.Checked = false;
                    }
                    stoplogging();
                }
            }
        }

        private void stoplogging()
        {
            string funcname = "stoplogging: ";

            LogMessageToErrorFile(funcname + "START======");
            LogMessageToErrorFile(funcname + "Error occured. Stopping logging now");
            LogMessageToErrorFile(funcname + "Stop interval timer");
            automaterunning = false;
            intervaltimer.Stop();
            intervaltimer.Enabled = false;
            logstatusvaluelbl.Text = "Stopped";
            loggingstartstopbtn.Text = "Start";
            fetchdatalbl.Text = "..";
            fetchdatalbl.Update();
            // No need to uncheck logging boxes because the routines are only called from 
            // the interval timer, which is now disabled
            LogMessageToErrorFile(funcname + "END======");
        }

        public void PauseForTime(int myseconds, int mymseconds)
        {
            // this is a generic wait that works with all versions of .NET
            System.DateTime ThisMoment = System.DateTime.Now;
            System.TimeSpan duration = new System.TimeSpan(0, 0, 0, myseconds, mymseconds);
            // System.TimeSpan( days, hrs, mins, secs, millisecs);
            System.DateTime AfterWards = ThisMoment.Add(duration);

            while (AfterWards >= ThisMoment)
            {
                System.Windows.Forms.Application.DoEvents();
                ThisMoment = System.DateTime.Now;
            }
        }

        private void Exitbtn_Click(object sender, EventArgs e)
        {
            string funcname = "Exit: ";

            LogMessageToErrorFile(funcname + "Exit btn - Exiting application now");
            this.Close();
            Application.Exit();
        }

        private void exitMenu_Click(object sender, EventArgs e)
        {
            LogMessageToErrorFile("exitMenu: Exiting application now");
            this.Close();
        }

        private void aboutMenu_Click(object sender, EventArgs e)
        {
            string funcname = "aboutMenu: ";

            LogMessageToErrorFile(funcname + "START======");
            MessageBox.Show("mySQM+ TCP/IP LOGGER Application\nVersion=" + myVersion + CopyrightStr + "Firmware Version: " + ArduinoFirmwareRev, "mySQM+ TCP/IP LOGGER", MessageBoxButtons.OK);
            LogMessageToErrorFile(funcname + "END======");
        }

        private void mySQMPLUSTCPIPLOGGER_Load(object sender, EventArgs e)
        {
            string funcname = "Load: ";
            Rectangle resolution = Screen.PrimaryScreen.Bounds;
            Point myLocation;

            Properties.Settings.Default.Reload();

            myLocation = Properties.Settings.Default.FormLocation;
            if (myLocation.X > (resolution.Width - this.Size.Width))
            {
                myLocation.X = 0;
            }
            if (myLocation.Y > (resolution.Height - this.Size.Height))
            {
                myLocation.Y = 0;
            }
            this.Location = myLocation;

            if (System.Deployment.Application.ApplicationDeployment.IsNetworkDeployed)
            {
                myVersion = System.Deployment.Application.ApplicationDeployment.CurrentDeployment.CurrentVersion.ToString();
                this.Text = "mySQM+ TCP/IP LOGGER © R Brown 2020-2021 " + myVersion;
            }
            else
            {
                myVersion = "mySQM+ TCP/IP LOGGER © R Brown 2020-2021";
                this.Text = myVersion;
            }

            // get the path name for datalogfile and errorlogfile
            // all log files are in the same path
            // check to see if app setting for "LogPathName"
            logpathfrm = new logfileform();
            CloudSensorForm = new GetCloudSensorIILogFilename();

            thisCulture = CultureInfo.CurrentCulture;
            thisICCulture = CultureInfo.CurrentUICulture;
            us_english = CultureInfo.CreateSpecificCulture("en-US");

            CSIItestoutput = false;

            windVeryWindy = Properties.Settings.Default.windVeryWindy;
            windWindy = Properties.Settings.Default.windWindy;
            cloudVeryCloudy = Properties.Settings.Default.cloudVeryCloudy;
            cloudCloudy = Properties.Settings.Default.cloudCloudy;
            dayVeryLight = Properties.Settings.Default.dayVeryLight;
            dayLight = Properties.Settings.Default.dayLight;

            windVeryWindytxtbox.Text = windVeryWindy.ToString("F1");
            windWindytxtbox.Text = windWindy.ToString("F1");
            cloudVeryCloudytxtbox.Text = cloudVeryCloudy.ToString("F1");
            cloudCloudytxtbox.Text = cloudCloudy.ToString("F1");
            dayVeryLighttxtbox.Text = dayVeryLight.ToString("F1");
            dayLighttxtbox.Text = dayLight.ToString("F1");

            automaterunning = false;
            loggingstartstopbtn.Text = "Start";
            intervaltimer.Enabled = false;

            // Set up all the logging
            string PathStr = Properties.Settings.Default.LogPathName;

            if (PathStr == "")
            {
                // its not set so activate form logfileform and get foldername
                // and save back into application setting
                logpathfrm.ShowDialog();
            }
            // in case it has changed, redo PathStr
            Properties.Settings.Default.Reload();
            PathStr = Properties.Settings.Default.LogPathName;

            // make up data logfilename
            string DateNow = DateTime.Now.ToString("yyyyMMdd-HHmmss");

            // make up logfilenames
            Errorlogfilename = "mySQMP-TLOG-Error-" + DateNow + ".txt";
            Datalogfilename = "mySQMP-TLOG-Data-" + DateNow + ".csv";
            CSlogfilename = Properties.Settings.Default.CloudSensorIILogFilename;
            // CSlogfilename = "mySQMP-CS2log";

            // remove any extension and then add extension .txt
            if (CSlogfilename.IndexOf('.') > 0)
            {
                CSlogfilename = CSlogfilename.Substring(0, CSlogfilename.IndexOf('.')) + ".txt";
            }
            else
            {
                CSlogfilename = CSlogfilename + ".txt";
            }

            // now work out absolute paths and save back into settings
            // get full pathname for datalog
            int pathlen = PathStr.Length;
            if (pathlen == 3)       // "D:\\" or "C:\\" - root directory
            {
                Datalogfilename = PathStr + Datalogfilename;
                Errorlogfilename = PathStr + Errorlogfilename;
                CSlogfilename = PathStr + CSlogfilename;
            }
            else
            {
                Datalogfilename = PathStr + "\\" + Datalogfilename;
                Errorlogfilename = PathStr + "\\" + Errorlogfilename;
                CSlogfilename = PathStr + "\\" + CSlogfilename;
            }

            LogMessageToErrorFile(funcname + "ErrorLogFileName: " + Errorlogfilename);
            LogMessageToErrorFile(funcname + "DataLogFileName: " + Datalogfilename);
            LogMessageToErrorFile(funcname + "CSIILogFileName: " + CSlogfilename);

            // restore logging interval
            int lograte = Properties.Settings.Default.Dataloggingrate / 1000;
            LogMessageToErrorFile(funcname + "Restore logging rate: " + lograte.ToString() + " seconds");
            switch (Properties.Settings.Default.Dataloggingrate)
            {
                case 30000:
                    automate30s.Checked = true;
                    break;
                case 60000:
                    automate1m.Checked = true;
                    break;
                case 60000 * 5:
                    automate5m.Checked = true;
                    break;
                case 60000 * 10:
                    automate10m.Checked = true;
                    break;
                case 60000 * 15:
                    automate15m.Checked = true;
                    break;
                case 60000 * 30:
                    automate30m.Checked = true;
                    break;
                default:
                    automate5m.Checked = true;
                    break;
            }

            // always start with logging disabled by default
            // Properties.Settings.Default.DataLogFileEnabled = false;
            // LogValuesChkBox.Enabled = false;
            // Properties.Settings.Default.ErrorLoggingEnabled = false;
            // LogErrorsChkBox.Enabled = false;             // leave enabled so as to get start messages
            Properties.Settings.Default.Save();

            ArduinoFirmwareRev = "NotConnected";

            statustxtbox.Clear();
            statustxtbox.Update();

            // set alert popup raining 
            LogMessageToErrorFile(funcname + "Restore raining-alert state");
            if (Properties.Settings.Default.RainingAlert == true)
            {
                enableAlertPopupMenuItem.Checked = true;
                disableAlertPopoupMenuItem.Checked = false;
            }
            else
            {
                enableAlertPopupMenuItem.Checked = false;
                disableAlertPopoupMenuItem.Checked = true;
            }

            Properties.Settings.Default.Save();

            LogMessageToErrorFile(funcname + "Restore TCP/IP Connection details");
            serverIP = ServerIpAddress.Text;
            try
            {
                server_ipaddr = IPAddress.Parse(serverIP);
                LogMessageToErrorFile(funcname + "Server address: " + ServerIpAddress.Text);
            }
            catch (FormatException)
            {
                LogMessageToErrorFile(funcname + "Format exception when converting ServerIP address: ");
                statustxtbox.Text = "Format exception when converting ServerIP address. Reset to 127.0.0.1";
                statustxtbox.Update();
                ServerIpAddress.Text = "127.0.0.1";
                LogMessageToErrorFile(funcname + "Reset address to loopback: 127.0.0.1");
                ServerIpAddress.Update();
                serverIP = ServerIpAddress.Text;
                server_ipaddr = IPAddress.Parse(serverIP);
                Badresponse();
            }

            // set focus to connection tab
            LogMessageToErrorFile(funcname + "Set connection tab as focus");
            this.maintabcontrol.SelectedTab = this.maintabcontrol.TabPages["connectiontab"];
            this.connectiontab.Focus();

            // set plot points to 0
            LogMessageToErrorFile(funcname + "Clear all graph points to 0");
            sqmluxchartobjectplotcount = 0;
            tempchartobjectplotcount = 0;
            windspeedchartplotcount = 0;
            bme280humiditychartplotcount = 0;
            bme280pressurechartplotcount = 0;

            LogMessageToErrorFile(funcname + "Initialize all graphs");
            // format secondary y axis on sqmlux chart to display low values of lux
            // this need to be dynamic, and then recalculate axises
            sqmluxchart.ChartAreas["ChartArea1"].AxisY2.LabelStyle.Format = "###.######";

            // set x and y label sizes
            sqmluxchart.ChartAreas["ChartArea1"].AxisX.LabelStyle.Font = new System.Drawing.Font("Arial", 6.0F, System.Drawing.FontStyle.Regular);
            tempchart.ChartAreas["ChartArea1"].AxisX.LabelStyle.Font = new System.Drawing.Font("Arial", 6.0F, System.Drawing.FontStyle.Regular);
            sqmluxchart.ChartAreas["ChartArea1"].AxisY.LabelStyle.Font = new System.Drawing.Font("Arial", 7.0F, System.Drawing.FontStyle.Regular);
            tempchart.ChartAreas["ChartArea1"].AxisY.LabelStyle.Font = new System.Drawing.Font("Arial", 7.0F, System.Drawing.FontStyle.Regular);

            // turn off the vertical lines in the chart
            sqmluxchart.ChartAreas["ChartArea1"].AxisX.MajorGrid.Enabled = false;
            tempchart.ChartAreas["ChartArea1"].AxisX.MajorGrid.Enabled = false;

            // set labels on x axis - spacing between datapoints = 1 label per datapoint
            sqmluxchart.ChartAreas["ChartArea1"].AxisX.Interval = 1;
            tempchart.ChartAreas["ChartArea1"].AxisX.Interval = 1;

            // set label style x axis to 90 so they are vertical
            sqmluxchart.ChartAreas["ChartArea1"].AxisX.LabelStyle.Angle = 90;
            tempchart.ChartAreas["ChartArea1"].AxisX.LabelStyle.Angle = 90;

            logstatusvaluelbl.Text = "Stopped";
            fetchdatalbl.Text = "..";

            LogMessageToErrorFile(funcname + "Initialize all data groups");
            mytemperaturegroup = new temperaturegroup();
            myweathergroup = new weathergroup();
            mydarkskygroup = new darkskygroup();
            mygpsgroup = new gpsgroup();
            myrainfallgroup = new rainfallgroup();
            myaboutgrp = new aboutgroup();

            LogMessageToErrorFile(funcname + "Get current data and time for timestamps in log files");
            lastUpdateCSII = DateTime.Now;
            lastUpdatedata = DateTime.Now;

            // This lets the form capture keyboard events before
            // any other element in the form.
            LogMessageToErrorFile(funcname + "Set key shortcuts");
            this.KeyPreview = true;
            // Assign the event handler to the form.
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.mySQMPLUSTCPIPLOGGER_KeyDown);
            LogMessageToErrorFile(funcname + "Application has completed startup sequence: SUCCESS");
            // application is running and awaiting events
        }

        // this is the data logging function called at regular intervals if enabled
        private void intervaltimer_Tick(object sender, EventArgs e)
        {
            string funcname = "intervaltimer: ";
            bool status;

            LogMessageToErrorFile(funcname + "START======");

            fetchdatalbl.Text = "Fetch data";
            fetchdatalbl.Update();

            statustxtbox.Text = "Interval timer triggered";
            statustxtbox.Update();

            status = true;
            // get parameters from the controller and fill in the boxes
            LogMessageToErrorFile(funcname + "Calling getallvalues");
            status = getallvaluesfromcontroller();
            LogMessageToErrorFile(funcname + "return state: " + status.ToString());
            if (status == false)
            {
                LogMessageToErrorFile(funcname + "err: getallvaluesfromcontroller(): Fail");
                fetchdatalbl.Text = "..";
                fetchdatalbl.Update();
                return;
            }

            // log data if enabled
            if (LogValuesChkBox.Checked == true)
            {
                LogMessageToErrorFile(funcname + "calling: log data values");
                writedatavaluestodatafile();
            }
            else
            {
                LogMessageToErrorFile(funcname + "logvalues is not enabled");
            }

            // if cloud sensor logging enabled
            if (CloudSensorIILogEnablechkbox.Checked == true)
            {
                LogMessageToErrorFile(funcname + "calling: log csii values");
                writecloudsensorfile();
            }
            else
            {
                LogMessageToErrorFile(funcname + "logCSII is not enabled");
            }

            fetchdatalbl.Text = "..";
            fetchdatalbl.Update();

            statustxtbox.Text = "Interval timer end";
            statustxtbox.Update();
            LogMessageToErrorFile(funcname + "END======");
        }

        private void checkrainalert()
        {
            if (Properties.Settings.Default.RainingAlert == true)
            {
                if (Raining == true)
                {
                    DialogResult dr;
                    dr = MessageBox.Show("IT IS RAINING." + System.Environment.NewLine + "Click Cancel to Disable rain alert or OK to continue", "mySQM+ TCP/IP LOGGER", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    // disable timer
                    if (automaterunning == true)
                    {
                        intervaltimer.Stop();
                        intervaltimer.Enabled = false;
                    }

                    switch (dr)
                    {
                        case DialogResult.Cancel:      // disable
                            Properties.Settings.Default.RainingAlert = false;
                            Properties.Settings.Default.Save();
                            disableAlertPopoupMenuItem.Checked = true;
                            enableAlertPopupMenuItem.Checked = false;
                            break;
                        case DialogResult.OK:          // enable
                        default:
                            Properties.Settings.Default.RainingAlert = true;
                            Properties.Settings.Default.Save();
                            disableAlertPopoupMenuItem.Checked = false;
                            enableAlertPopupMenuItem.Checked = true;
                            break;
                    }
                    // re-enable timer
                    if (automaterunning == true)
                    {
                        intervaltimer.Enabled = true;
                        intervaltimer.Start();
                    }
                }
            }
        }

        private void addtochart()
        {
            string funcname = "addtochart: ";
            string TimeNow;
            string myTime = "";

            // graph to maintabcontrol
            // sqmnelmchart
            sqmluxchart.ChartAreas[0].RecalculateAxesScale();
            // Calculate current time as this needs to be plotted on Graph X
            TimeNow = DateTime.Now.TimeOfDay.ToString();       // get current time
            for (int lpval = 0; lpval <= 7; lpval++)           // hh:mm:ss.nnnnn
            {
                myTime += TimeNow[lpval];
            }
            myTime += "";                                       // hh.mm.ss

            if (sqmluxchartobjectplotcount > numberofpointplots)
            {
                try
                {
                    sqmluxchart.Series["SQM"].Points.RemoveAt(0);
                    sqmluxchart.Series["LUX"].Points.RemoveAt(0);
                }
                catch (NullReferenceException)
                {
                    LogMessageToErrorFile(funcname + " Error: removing sqm/lux data from chart plot");
                }
            }
            // add the point (temperature, time) to the chart
            // chart1.Series["Temp"].XValueType = ChartValueType.Time;
            try
            {

                sqmluxchart.Series["SQM"].Points.AddXY(myTime, mydarkskygroup.sqm);
                sqmluxchart.Series["LUX"].Points.AddXY(myTime, mydarkskygroup.lux);
            }
            catch (NullReferenceException)
            {
                LogMessageToErrorFile(funcname + " Error: adding sqm/lux data to chart plot");
            }
            sqmluxchartobjectplotcount++;

            // tempgraph
            tempchart.ChartAreas[0].RecalculateAxesScale();
            if (tempchartobjectplotcount > numberofpointplots)
            {
                try
                {
                    tempchart.Series["Ambient"].Points.RemoveAt(0);
                    tempchart.Series["Dewpoint"].Points.RemoveAt(0);
                    tempchart.Series["SkyAmbient"].Points.RemoveAt(0);
                    tempchart.Series["SkyObject"].Points.RemoveAt(0);
                }
                catch (NullReferenceException)
                {
                    LogMessageToErrorFile(funcname + " Error: removing tempgraph data from chart plot");
                }
            }
            // add the point (temperature, time) to the chart
            // chart1.Series["Temp"].XValueType = ChartValueType.Time;
            try
            {
                tempchart.Series["Ambient"].Points.AddXY(myTime, mytemperaturegroup.ambient);
                tempchart.Series["Dewpoint"].Points.AddXY(myTime, mytemperaturegroup.dewpoint);
                tempchart.Series["SkyAmbient"].Points.AddXY(myTime, mytemperaturegroup.skyambient);
                tempchart.Series["SkyObject"].Points.AddXY(myTime, mytemperaturegroup.skyobject);
            }
            catch (NullReferenceException)
            {
                LogMessageToErrorFile(funcname + " Error: adding tempgraph data to chart plot");
            }
            tempchartobjectplotcount++;
        }

        private bool getallvaluesfromcontroller()
        {
            string funcname = "getallvalues: ";
            string baseurl;
            bool result = true;
            Stream jsonresponse;
            StreamReader sr;

            LogMessageToErrorFile(funcname + "START======");
            statustxtbox.Text = "getallvaluesfromcontroller triggered";
            statustxtbox.Update();

            serverIP = ServerIpAddress.Text;
            try
            {
                server_ipaddr = IPAddress.Parse(serverIP);
            }
            catch (FormatException)
            {
                LogMessageToErrorFile(funcname + " Format exception when converting ServerIP address.");
                statustxtbox.Text = "Format exception when converting ServerIP address. Reset to 192.168.4.1";
                statustxtbox.Update();
                ServerIpAddress.Text = "192.168.4.1";
                serverIP = ServerIpAddress.Text;
                server_ipaddr = IPAddress.Parse(serverIP);
                stoplogging();
                result = false;
            }

            LogMessageToErrorFile("Chk1 Result: " + result.ToString());
            client = new WebClient();
            client.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)");

            // TEMPERATURE=t1, WEATHER=w1, DARKSKY=d1, GPSSTATUS=g1
            // temperature group request
            // bme280ambient, dewpoint, mlx90614ambient, mlx90614object
            statustxtbox.Text = "Get /t1";
            statustxtbox.Update();
            LogMessageToErrorFile(funcname + " Get temperature group");

            baseurl = "http://" + serverIP + "/t1";
            jsonresponse = client.OpenRead(baseurl);
            sr = new StreamReader(jsonresponse);
            // The stream data is used here.
            string response = sr.ReadToEnd();
            if (response != "")
            {
                LogMessageToErrorFile(funcname + " Get temperature group: " + response);
                JavaScriptSerializer jsonSerializer = new JavaScriptSerializer();
                try
                {
                    mytemperaturegroup = jsonSerializer.Deserialize<temperaturegroup>(response);
                }
                catch (System.ArgumentNullException ex)
                {
                    LogMessageToErrorFile(funcname + "err: " + ex.ToString());
                    result = false;
                }
                catch (System.ArgumentException ex)
                {
                    LogMessageToErrorFile(funcname + "err: " + ex.ToString());
                    result = false;
                }
                catch (System.InvalidOperationException ex)
                {
                    LogMessageToErrorFile(funcname + "err: " + ex.ToString());
                    result = false;
                }
            }
            else
            {
                LogMessageToErrorFile(funcname + " Error: Get temperature group");
                result = false;
            }
            jsonresponse.Close();
            LogMessageToErrorFile("Chk2 Result: " + result.ToString());

            // get weather group request
            // humidity, pressure, raining, rvout, windspeed, winddirection
            statustxtbox.Text = "Get /w1";
            statustxtbox.Update();
            LogMessageToErrorFile(funcname + " Get weather group");
            baseurl = "http://" + serverIP + "/w1";
            jsonresponse = client.OpenRead(baseurl);
            sr = new StreamReader(jsonresponse);
            // The stream data is used here.
            response = sr.ReadToEnd();
            if (response != "")
            {
                LogMessageToErrorFile(funcname + " Get weather group: " + response);
                JavaScriptSerializer jsonSerializer = new JavaScriptSerializer();
                try
                {
                    myweathergroup = jsonSerializer.Deserialize<weathergroup>(response);
                }
                catch (System.ArgumentNullException ex)
                {
                    LogMessageToErrorFile(funcname + "err: " + ex.ToString());
                    result = false;
                }
                catch (System.ArgumentException ex)
                {
                    LogMessageToErrorFile(funcname + "err: " + ex.ToString());
                    result = false;
                }
                catch (System.InvalidOperationException ex)
                {
                    LogMessageToErrorFile(funcname + "err: " + ex.ToString());
                    result = false;
                }
            }
            else
            {
                LogMessageToErrorFile(funcname + " Error: Get weather group");
                result = false;
            }
            jsonresponse.Close();
            LogMessageToErrorFile("Chk3 Result: " + result.ToString());

            // get dark sky group request
            // sqm, nelm, lux, skystate, cloudcover
            statustxtbox.Text = "Get /d1";
            statustxtbox.Update();
            LogMessageToErrorFile(funcname + " Get dark sky group");
            baseurl = "http://" + serverIP + "/d1";
            jsonresponse = client.OpenRead(baseurl);
            sr = new StreamReader(jsonresponse);
            // The stream data is used here.
            response = sr.ReadToEnd();
            if (response != "")
            {
                LogMessageToErrorFile(funcname + " Get dark sky group: " + response);
                JavaScriptSerializer jsonSerializer = new JavaScriptSerializer();
                try
                {
                    mydarkskygroup = jsonSerializer.Deserialize<darkskygroup>(response);
                }
                catch (System.ArgumentNullException ex)
                {
                    LogMessageToErrorFile(funcname + "err: " + ex.ToString());
                    result = false;
                }
                catch (System.ArgumentException ex)
                {
                    LogMessageToErrorFile(funcname + "err: " + ex.ToString());
                    result = false;
                }
                catch (System.InvalidOperationException ex)
                {
                    LogMessageToErrorFile(funcname + "err: " + ex.ToString());
                    result = false;
                }
            }
            else
            {
                LogMessageToErrorFile(funcname + " Error: Get dark sky group");
                result = false;
            }
            jsonresponse.Close();
            LogMessageToErrorFile("Chk4 Result: " + result.ToString());

            // get gps group request
            // date, time, latitude, longitude, mysatellittes, myaltitude, myfix
            statustxtbox.Text = "Get /g1";
            statustxtbox.Update();
            LogMessageToErrorFile(funcname + " Get gps group");
            baseurl = "http://" + serverIP + "/g1";
            jsonresponse = client.OpenRead(baseurl);
            sr = new StreamReader(jsonresponse);
            // The stream data is used here.
            response = sr.ReadToEnd();
            if (response != "")
            {
                LogMessageToErrorFile(funcname + " Get gps group: " + response);
                JavaScriptSerializer jsonSerializer = new JavaScriptSerializer();
                try
                {
                    mygpsgroup = jsonSerializer.Deserialize<gpsgroup>(response);
                    LogMessageToErrorFile(funcname + "gpsdate: " + mygpsgroup.gpsdate);
                }
                catch (System.ArgumentNullException ex)
                {
                    LogMessageToErrorFile(funcname + "err: " + ex.ToString());
                    result = false;
                }
                catch (System.ArgumentException ex)
                {
                    LogMessageToErrorFile(funcname + "err: " + ex.ToString());
                    result = false;
                }
                catch (System.InvalidOperationException ex)
                {
                    LogMessageToErrorFile(funcname + "err: " + ex.ToString());
                    result = false;
                }
            }
            else
            {
                LogMessageToErrorFile(funcname + " Error: Get gps group");
                result = false;
            }
            jsonresponse.Close();
            LogMessageToErrorFile("Chk5 Result: " + result.ToString());

            // rainfall group
            //   { "rainhour":xx.x,"rainphour":xx.x, "rainday":xx.x,"rainpday":xx.x }";
            statustxtbox.Text = "Get /rain";
            statustxtbox.Update();
            LogMessageToErrorFile(funcname + " Get rainfall group");
            baseurl = "http://" + serverIP + "/rain";
            jsonresponse = client.OpenRead(baseurl);
            sr = new StreamReader(jsonresponse);
            // The stream data is used here.
            response = sr.ReadToEnd();
            if (response != "")
            {
                LogMessageToErrorFile(funcname + " Get rainfall group: " + response);
                JavaScriptSerializer jsonSerializer = new JavaScriptSerializer();
                try
                {
                    myrainfallgroup = jsonSerializer.Deserialize<rainfallgroup>(response);
                }
                catch (System.ArgumentNullException ex)
                {
                    LogMessageToErrorFile(funcname + "err: " + ex.ToString());
                    result = false;
                }
                catch (System.ArgumentException ex)
                {
                    LogMessageToErrorFile(funcname + "err: " + ex.ToString());
                    result = false;
                }
                catch (System.InvalidOperationException ex)
                {
                    LogMessageToErrorFile(funcname + "err: " + ex.ToString());
                    result = false;
                }
            }
            else
            {
                LogMessageToErrorFile(funcname + " Error: Get rainfall group");
                result = false;
            }
            jsonresponse.Close();
            LogMessageToErrorFile("Chk6 Result: " + result.ToString());

            // firmware
            // /about REQUEST /about 
            statustxtbox.Text = "Get /about";
            statustxtbox.Update();
            LogMessageToErrorFile(funcname + " Get about group");
            baseurl = "http://" + serverIP + "/about";
            jsonresponse = client.OpenRead(baseurl);
            sr = new StreamReader(jsonresponse);
            // The stream data is used here.
            response = sr.ReadToEnd();
            if (response != "")
            {
                LogMessageToErrorFile(funcname + " Get about group: " + response);
                JavaScriptSerializer jsonSerializer = new JavaScriptSerializer();
                try
                {
                    myaboutgrp = jsonSerializer.Deserialize<aboutgroup>(response);
                }
                catch (System.ArgumentNullException ex)
                {
                    LogMessageToErrorFile(funcname + "err: " + ex.ToString());
                    result = false;
                }
                catch (System.ArgumentException ex)
                {
                    LogMessageToErrorFile(funcname + "err: " + ex.ToString());
                    result = false;
                }
                catch (System.InvalidOperationException ex)
                {
                    LogMessageToErrorFile(funcname + "err: " + ex.ToString());
                    result = false;
                }
            }
            else
            {
                LogMessageToErrorFile(funcname + "err: Get about group");
                result = false;
            }
            jsonresponse.Close();
            LogMessageToErrorFile("Chk7 Result: " + result.ToString());

            // other get calls here
            // Log in errorfile

            LogMessageToErrorFile(funcname + "sqm: " + mydarkskygroup.sqm.ToString("F2", us_english));
            LogMessageToErrorFile(funcname + "lux: " + mydarkskygroup.lux.ToString("F5", us_english));
            LogMessageToErrorFile(funcname + "skyambient: " + mytemperaturegroup.skyambient.ToString("F2", us_english));
            LogMessageToErrorFile(funcname + "skyobject: " + mytemperaturegroup.skyobject.ToString("F2", us_english));
            LogMessageToErrorFile(funcname + "ver: " + myaboutgrp.ver);
            LogMessageToErrorFile(funcname + "raining: " + myweathergroup.raining.ToString());
            LogMessageToErrorFile(funcname + "rvout: " + myweathergroup.rvout.ToString("F2", us_english));
            LogMessageToErrorFile(funcname + "nelm: " + mydarkskygroup.nelm.ToString("F2", us_english));
            LogMessageToErrorFile(funcname + "ambient: " + mytemperaturegroup.ambient.ToString("F2", us_english));
            LogMessageToErrorFile(funcname + "humidity: " + myweathergroup.humidity.ToString("F2", us_english));
            LogMessageToErrorFile(funcname + "dewpoint: " + mytemperaturegroup.dewpoint.ToString("F2", us_english));
            LogMessageToErrorFile(funcname + "pressure: " + myweathergroup.pressure.ToString("F2", us_english));
            LogMessageToErrorFile(funcname + "gpsdate: " + mygpsgroup.gpsdate);
            LogMessageToErrorFile(funcname + "gpstime: " + mygpsgroup.gpstime);
            LogMessageToErrorFile(funcname + "gpslon: " + mygpsgroup.gpslon);
            LogMessageToErrorFile(funcname + "gpslat: " + mygpsgroup.gpslat);
            LogMessageToErrorFile(funcname + "gpssat: " + mygpsgroup.gpssat);
            LogMessageToErrorFile(funcname + "gpsalt: " + mygpsgroup.gpsalt);
            LogMessageToErrorFile(funcname + "gpsfix: " + mygpsgroup.gpsfix);
            LogMessageToErrorFile(funcname + "skystate: " + mydarkskygroup.skystate.ToString());
            LogMessageToErrorFile(funcname + "windspeed: " + myweathergroup.windspd.ToString("F2", us_english));
            LogMessageToErrorFile(funcname + "winddir: " + myweathergroup.winddir.ToString());
            LogMessageToErrorFile(funcname + "cloudcover: " + mydarkskygroup.cloudcover.ToString("F2", us_english));
            LogMessageToErrorFile(funcname + "raincurrhr: " + myrainfallgroup.raincurrhr.ToString("F2", us_english));
            LogMessageToErrorFile(funcname + "raincurrday: " + myrainfallgroup.raincurrday.ToString("F2", us_english));
            LogMessageToErrorFile(funcname + "rainprevhr: " + myrainfallgroup.rainprevhr.ToString("F2", us_english));
            LogMessageToErrorFile(funcname + "rainprevday: " + myrainfallgroup.rainprevday.ToString("F2", us_english));
            LogMessageToErrorFile(funcname + "product: " + myaboutgrp.product);
            LogMessageToErrorFile(funcname + "Author: " + myaboutgrp.Author);

            LogMessageToErrorFile("Chk8 Result: " + result.ToString());

            addtochart();
            LogMessageToErrorFile("Chk9 Result: " + result.ToString());

            LogMessageToErrorFile(funcname + "END======");
            statustxtbox.Text = "getallvalues: end";
            statustxtbox.Update();
            return result;
        }

        // this writes the data values to the logfile in JSON
        private void writedatavaluestodatafile()
        {
            string funcname = "writedatavalues: ";
            string DataStr = "";

            // issue - writing as string to file causes locale issue - 21,95 is written as 21,95
            // and not 21.95

            LogMessageToErrorFile(funcname + "START======");

            if (LogValuesChkBox.Checked == true)
            {
                LogMessageToErrorFile(funcname + "LogData enabled");
                // create the file
                try
                {
                    if (!File.Exists(Datalogfilename))
                    {
                        LogMessageToErrorFile(funcname + "data log file does not exist: Create file");
                        FileStream fs = File.Create(Datalogfilename);
                        fs.Close();
                    }
                    else
                    {
                        // MessageBox.Show("File Exists Already", "mySQM+ TCP/IP LOGGER", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception Ex)
                {
                    MessageBox.Show("Error creating log file. Cannot Access Location: " + Ex.Message, "mySQM+ TCP/IP LOGGER", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    statustxtbox.Text = "Exception Error creating log file";
                    statustxtbox.Update();
                    LogMessageToErrorFile(funcname + "Exception Error creating values log file");
                    stoplogging();
                }
            }

            LogMessageToErrorFile(funcname + "writing data values");

            string DateNow = DateTime.Now.ToString("yyyy/MM/dd");
            string TimeNow = DateTime.Now.ToString("hh:MM:ss");

            // controller type
            DataStr = "{ \"controllertype\": \"mysqmplus\",";
            // date and time       
            DataStr = DataStr + "\"date\":\"" + DateNow + "\",{\"time\":\"" + TimeNow + "\", ";

            // now log the data values
            // make sure it is in the correct culture en-us
            // var.ToString(enUS)

            string value;

            value = mydarkskygroup.sqm.ToString("F2", CultureInfo.InvariantCulture);
            DataStr += "\"sqm\":" + value + ", ";

            value = mydarkskygroup.lux.ToString("F3", CultureInfo.InvariantCulture);
            DataStr += "\"lux\":" + value + ", ";

            value = mydarkskygroup.nelm.ToString("F2", CultureInfo.InvariantCulture);
            DataStr += "\"nelm\":" + value + ", ";

            value = mytemperaturegroup.ambient.ToString("F2", CultureInfo.InvariantCulture);
            DataStr += "\"ambient\":" + value + ", ";

            value = myweathergroup.humidity.ToString("F2", CultureInfo.InvariantCulture);
            DataStr += "\"humidity\":" + value + ", ";

            value = mytemperaturegroup.dewpoint.ToString("F2", CultureInfo.InvariantCulture);
            DataStr += "\"dewpoint\":" + value + ", ";

            value = myweathergroup.pressure.ToString();
            DataStr += "\"pressure\":" + value + ", ";

            value = mytemperaturegroup.skyobject.ToString("F2", CultureInfo.InvariantCulture);
            DataStr += "\"skyobject\":" + value + ", ";

            value = mytemperaturegroup.skyambient.ToString("F2", CultureInfo.InvariantCulture);
            DataStr += "\"skyambient\":" + value + ", ";

            value = myweathergroup.raining.ToString();
            DataStr += "\"rain\":" + value + ", ";

            value = myweathergroup.rvout.ToString("F2", CultureInfo.InvariantCulture);
            DataStr += "\"rvout\":" + value + ", ";

            value = myrainfallgroup.raincurrhr.ToString("F2", CultureInfo.InvariantCulture);
            DataStr += "\"raincurrhr\":" + value + ", ";

            value = myrainfallgroup.raincurrday.ToString("F2", CultureInfo.InvariantCulture);
            DataStr += "\"raincurrday\":" + value + ", ";

            value = mydarkskygroup.skystate.ToString();
            DataStr += "\"skystate\":" + value + ", ";

            value = myweathergroup.windspd.ToString("F2", CultureInfo.InvariantCulture);
            DataStr += "\"windspd\":" + value + ", ";

            value = myweathergroup.winddir.ToString();
            DataStr += "\"winddir\":" + value + ", ";

            value = mydarkskygroup.cloudcover.ToString("F2", CultureInfo.InvariantCulture);
            DataStr += "\"cloudcover\":" + value + ", ";

            // strip any trailing ,
            DataStr = DataStr.Substring(0, DataStr.Length - 1);
            DataStr += "}";

            LogMessageToErrorFile(funcname + "Writing to File: " + Datalogfilename);
            LogMessageToErrorFile(funcname + "with this Data: " + DataStr);

            string bufferdata = DataStr + System.Environment.NewLine;
            try
            {
                File.AppendAllText(Datalogfilename, bufferdata);
                LogMessageToErrorFile(funcname + "Success");
            }
            catch (Exception)
            {
                LogMessageToErrorFile(funcname + "Fail");
                MessageBox.Show("Error writing to data logfile: ", "mySQM+ TCP/IP LOGGER", MessageBoxButtons.OK, MessageBoxIcon.Error);
                stoplogging();
            }
            lastUpdatedata = DateTime.Now;

            LogMessageToErrorFile(funcname + "END======");
        }

        private void writecloudsensorfile()
        {
            string funcname = "writecloudsensorfile: ";
            // Date       Time        T V  SkyT AmbT SenT Wind Hum DewPt Hea R W Since Now() Day's  c w r d C A
            // 2005-06-03 02:07:23.34 C K -28.5 18.7 22.5 45.3 75  10.3  3   0 0 00004 038506.08846 1 2 1 0 0 0

            LogMessageToErrorFile(funcname + "START======");
            if (CloudSensorIILogEnablechkbox.Checked == true)
            {
                int currentcloudstate;
                int windcondition;
                int raincondition;
                int daylightcondition;

                var t = (DateTime.Now - lastUpdateCSII).TotalSeconds.ToString("00000");
                var dn = DateTime.Now.ToString("yyyy-MM-dd");
                var tn = DateTime.Now.ToString("HH:mm:ss.ss");
                var now = DateTime.Now.ToOADate().ToString("000000.00000", us_english);

                LogMessageToErrorFile(funcname + "writing cloud sensor file");

                /*
                string line = string.Format(us_english,
                    "{0} C K {1,6:F1} {2,6:F1} {3,6:F1} {4,6:F1} {5,3:F0} {6,6:F1} {7,3:F0} {8} {9} {10} {11} {12} {13} {14} {15} {16} {17}",
                    dt,                                 // 0 2005-06-03 02:07:23.34
                    mytemperaturegroup.irobject,        // 1 SkyT infra-red
                    mytemperaturegroup.ambient,         // 2 AmbT
                    mytemperaturegroup.ambient + 5,     // 3 SenT
                    myweathergroup.windspeed,           // 4 Wind
                    myweathergroup.humidity,            // 5 Hum
                    mytemperaturegroup.dewpoint,        // 6 DewPt
                    0,                                  // 7 Heater
                    "0",                                // 8 R Requesting Roof Close
                    "0",                                // 9 W
                    t,                                  // 10 Since
                    now,                                // 11 Now() "038506.08846",
                    currentcloudstate,                  // 12 c cloud condition (see the Cloudcond enum in section 20) 
                    windcondition,                      // 13 w wind condition (see the Windcond enum in section 20)
                    raincondition,                      // 14 r rain condition (see the Raincond enum in section 20) 
                    daylightcondition,                  // 15 d daylight condition (see the Daycond enum in section 20) 
                    0,                                  // 16 C roof close, =0 not requested, =1 if roof close was requested on this cycle
                    0);                                 // 17 A alert, =0 when not alerting, =1 when alerting
                logdata_CSII_file(line);
                 * */

                double windVeryWindy;
                double windWindy;
                //double windcalm;
                windVeryWindy = Convert.ToDouble(windVeryWindytxtbox.Text, us_english);
                windWindy = Convert.ToDouble(windWindytxtbox.Text, us_english);
                Properties.Settings.Default.windVeryWindy = windVeryWindy;
                Properties.Settings.Default.windWindy = windWindy;

                double cloudVeryCloudy;
                double cloudCloudy;
                // double cloudclear;
                cloudVeryCloudy = Convert.ToDouble(cloudVeryCloudytxtbox.Text, us_english);
                cloudCloudy = Convert.ToDouble(cloudCloudytxtbox.Text, us_english);
                Properties.Settings.Default.cloudVeryCloudy = cloudVeryCloudy;
                Properties.Settings.Default.cloudCloudy = cloudCloudy;

                double dayVeryLight;
                double dayLight;
                dayVeryLight = Convert.ToDouble(dayVeryLighttxtbox.Text, us_english);
                dayLight = Convert.ToDouble(dayLighttxtbox.Text, us_english);
                Properties.Settings.Default.dayVeryLight = dayVeryLight;
                Properties.Settings.Default.dayLight = dayLight;

                // use cloud sensor II log file format
                string DataStr = "";
                // date
                DataStr = DataStr + dn;
                while (DataStr.Length < 11)
                {
                    DataStr = DataStr + " ";
                }

                // time
                DataStr = DataStr + tn;
                while (DataStr.Length < 23)
                {
                    DataStr = DataStr + " ";
                }

                // 24 temperature_mode C or F
                DataStr = DataStr + "C";
                while (DataStr.Length < 25)
                {
                    DataStr = DataStr + " ";
                }

                // 26 Wind_velocity_measurement unit m = m/s, K = kph, M=mph
                DataStr = DataStr + "m";
                while (DataStr.Length < 27)
                {
                    DataStr = DataStr + " ";
                }

                // 28-34 sky infra-red temperature 28-34
                // F1 means float format with 1 place
                DataStr = DataStr + mytemperaturegroup.skyobject.ToString("F1", us_english);
                while (DataStr.Length < 34)
                {
                    DataStr = DataStr + " ";
                }

                // 35-40 sky ambient temperature
                DataStr = DataStr + mytemperaturegroup.skyambient.ToString("F1", us_english);
                while (DataStr.Length < 40)
                {
                    DataStr = DataStr + " ";
                }

                // 41-47 sensor case temperature
                DataStr = DataStr + mytemperaturegroup.ambient.ToString("F1", us_english);
                while (DataStr.Length < 48)
                {
                    DataStr = DataStr + " ";
                }

                // 49-54 Wind Speed
                DataStr = DataStr + myweathergroup.windspd.ToString("F1", us_english);
                while (DataStr.Length < 55)
                {
                    DataStr = DataStr + " ";
                }

                // 56-58 Relative Humidity %
                int hum = Convert.ToInt32((int)myweathergroup.humidity);
                DataStr = DataStr + hum.ToString();
                while (DataStr.Length < 59)
                {
                    DataStr = DataStr + " ";
                }

                // 60-65 Dew Point (6 characters)
                DataStr = DataStr + mytemperaturegroup.dewpoint.ToString("F1", us_english);
                while (DataStr.Length < 66)
                {
                    DataStr = DataStr + " ";
                }

                // 67-69 Heater %
                DataStr = DataStr + "0";
                while (DataStr.Length < 70)
                {
                    DataStr = DataStr + " ";
                }

                // 71 Rain Flag 0-2, 0 for dry, =1 for rain in the last minute, =2 for rain right now
                // v18 if (Raining == true)
                LogMessageToErrorFile(funcname + "Rain Flag 71: input_rainflag_raw_value: " + myweathergroup.raining.ToString());
                int rainflag = 0;
                if (myweathergroup.raining == 1)
                {
                    rainflag = 2;       // rain now
                }
                else
                {
                    rainflag = 0;
                }
                LogMessageToErrorFile(funcname + "Rain Flag 71: output_rainflag: " + rainflag.ToString());
                DataStr = DataStr + rainflag.ToString();
                while (DataStr.Length < 72)
                {
                    DataStr = DataStr + " ";
                }

                // 73 Wet flag, 0 for dry, =1 for wet in the last minute, =2 for wet right now
                LogMessageToErrorFile(funcname + "Wet Flag 73: input_wetflag_raw_value: " + myweathergroup.raining.ToString());
                int wetflag = Convert.ToInt32(myweathergroup.raining);
                if (myweathergroup.raining == 1)
                {
                    wetflag = 2;
                }
                else
                {
                    wetflag = 1;
                }
                LogMessageToErrorFile(funcname + "Wet Flag 73: output_wetflag: " + wetflag.ToString());
                DataStr = DataStr + wetflag.ToString();
                while (DataStr.Length < 74)
                {
                    DataStr = DataStr + " ";
                }

                // 75-79 Since seconds since the last valid data
                DataStr = DataStr + t;
                while (DataStr.Length < 80)
                {
                    DataStr = DataStr + " ";
                }

                // Now() 81-92
                // date/time given as the VB6 Now() function result (in days) when Clarity II last
                // wrote this file
                // 038506.08846
                DataStr = DataStr + now;
                while (DataStr.Length < 93)
                {
                    DataStr = DataStr + " ";
                }

                // 94 c cloud sky state
                // cloudUnknown = 0, cloudClear = 1, cloudCloudy = 2, cloudVeryCloudy = 3
                LogMessageToErrorFile(funcname + "c 94: input_cloudcover_raw_value: " + mydarkskygroup.cloudcover.ToString("F3", us_english));
                if (mydarkskygroup.cloudcover > cloudVeryCloudy)
                {
                    currentcloudstate = 3;  // cloudVeryCloudy
                }
                else if ((mydarkskygroup.cloudcover >= cloudCloudy) && (mydarkskygroup.cloudcover < cloudVeryCloudy))
                {
                    currentcloudstate = 2;  // cloudCloudy
                }
                else
                {
                    currentcloudstate = 1;  // cloudClear
                }
                LogMessageToErrorFile(funcname + "c 94: output_currentcloudstate: " + currentcloudstate.ToString());
                DataStr = DataStr + currentcloudstate.ToString();
                while (DataStr.Length < 95)
                {
                    DataStr = DataStr + " ";
                }

                // 96 w wind condition
                // windUnknown = 0, windCalm = 1, windWindy = 2, windVeryWindy = 3
                LogMessageToErrorFile(funcname + "w 96: input_wind_speed_raw_value: " + myweathergroup.windspd.ToString("F2", us_english));
                windcondition = 0;      // unknown
                if (myweathergroup.windspd >= windVeryWindy)
                {
                    windcondition = 3;  // windVeryWindy
                }
                else if ((myweathergroup.windspd >= windWindy) && (myweathergroup.windspd < windVeryWindy))
                {
                    windcondition = 2;  // windWindy
                }
                else
                {
                    windcondition = 1;  // windCalm
                }
                LogMessageToErrorFile(funcname + "w 96: output_windcondition: " + windcondition.ToString());
                DataStr = DataStr + windcondition.ToString();
                while (DataStr.Length < 97)
                {
                    DataStr = DataStr + " ";
                }

                // 98 r rain condition
                // rainUnknown = 0, rainDry = 1,  rainWet = 2 'sensor has water on it, rainRain = 3 'falling rain drops detected
                LogMessageToErrorFile(funcname + "r 98: input_rain_raw_value: " + myweathergroup.raining.ToString());
                raincondition = 0;              // rainUnknown
                if (myweathergroup.raining == 1)
                {
                    raincondition = 3;          // rainWet
                }
                else
                {
                    raincondition = 1;          // rainDry
                }
                LogMessageToErrorFile(funcname + "r 98: output_raincondition: " + raincondition.ToString());
                DataStr = DataStr + raincondition.ToString();
                while (DataStr.Length < 99)
                {
                    DataStr = DataStr + " ";
                }

                // 100 d daylightcondition 
                // dayUnknown = 0, dayDark = 1, dayLight = 2, dayVeryLight = 3
                LogMessageToErrorFile(funcname + "100: input_lux_raw_value: " + mydarkskygroup.lux.ToString("F2", us_english));
                int lux_val = (int)mydarkskygroup.lux;
                daylightcondition = 0;      // unKnown
                if (lux_val >= dayVeryLight)
                {
                    daylightcondition = 3;  // dayVeryLight = 3
                }
                else if ((lux_val >= dayLight) && (lux_val < dayVeryLight))
                {
                    daylightcondition = 2;  // dayLight
                }
                else // lux_val < dayLight
                {
                    daylightcondition = 1;  // dayDark
                }
                LogMessageToErrorFile(funcname + "100: output_daylightcondition: " + daylightcondition.ToString());
                DataStr = DataStr + daylightcondition.ToString();
                while (DataStr.Length < 101)
                {
                    DataStr = DataStr + " ";
                }

                // 102 C roof close
                DataStr = DataStr + "0";    // not requested
                while (DataStr.Length < 103)
                {
                    DataStr = DataStr + " ";
                }

                // 104 A Alert
                DataStr = DataStr + "0";    // not alerting
                if (CSIItestoutput == true)
                {
                    MessageBox.Show(DataStr, "mySQM+ TCP/IP LOGGER", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                LogMessageToErrorFile(funcname + "Writing to File: " + CSlogfilename);
                LogMessageToErrorFile(funcname + "with this Data: " + DataStr);

                // Create a file to write to
                try
                {
                    // write all - creates file, writes data then closes file
                    // if the file already exists it is overwritten
                    File.WriteAllText(CSlogfilename, DataStr);
                    LogMessageToErrorFile(funcname + "Write CSII log Success");
                }
                catch (ArgumentException)
                {
                    LogMessageToErrorFile(funcname + "Write CSII log Fail");
                    LogMessageToErrorFile(funcname + "File did not exist. path is a zero-length string, contains only white space, or contains one or more invalid characters");
                    stoplogging();
                }
                catch (PathTooLongException)
                {
                    LogMessageToErrorFile(funcname + "Write CSII log Fail");
                    LogMessageToErrorFile(funcname + "The specified path, file name, or both exceed the system-defined maximum length. For example, on Windows-based platforms, paths must be less than 248 characters, and file names must be less than 260 characters");
                    stoplogging();
                }
                catch (DirectoryNotFoundException)
                {
                    LogMessageToErrorFile(funcname + "Write CSII log Fail");
                    LogMessageToErrorFile(funcname + "The specified path is invalid.");
                    stoplogging();
                }
                catch (IOException)
                {
                    LogMessageToErrorFile(funcname + "Write CSII log Fail");
                    LogMessageToErrorFile(funcname + "An I/O error occurred while opening the file. ");
                    stoplogging();
                }
                catch (UnauthorizedAccessException)
                {
                    LogMessageToErrorFile(funcname + "Write CSII log Fail");
                    LogMessageToErrorFile(funcname + "The caller does not have the required permission.");
                    stoplogging();
                }
                catch (NotSupportedException)
                {
                    LogMessageToErrorFile(funcname + "Write CSII log Fail");
                    LogMessageToErrorFile(funcname + "path is in an invalid format.");
                    stoplogging();
                }

                lastTime = DateTime.Now;
                LogMessageToErrorFile(funcname + "File written");
                lastUpdateCSII = DateTime.Now;
            }
            LogMessageToErrorFile(funcname + "END======");
        }

        private void mySQMGPS_FormClosing(object sender, FormClosingEventArgs e)
        {
            Properties.Settings.Default.FormLocation = this.Location;
            Properties.Settings.Default.Save();

            // need to stop automate if running
            intervaltimer.Stop();
            intervaltimer.Enabled = false;
            Properties.Settings.Default.Save();  // save the application settings
            Application.Exit();
        }

        private void forceExitMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult result;

            result = MessageBox.Show("Are you sure you want to force exit?", "mySQM+ TCP/IP LOGGER", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Information);

            if (result == DialogResult.Yes)
            {
                // force exit
                // flush serial buffers
                // close serial port etc
                // stop interval timer
                // print message
                intervaltimer.Enabled = false;
                statustxtbox.Text = "Force Exit of mySQM+ TCP/IP LOGGER done.";
                statustxtbox.Update();
                Properties.Settings.Default.Save();
                Environment.Exit(0);
            }
            else if (result == DialogResult.No)
            {
                // do nothing
                // print message port not disconnected
                statustxtbox.Text = "Force Exit of mySQM+ TCP/IP LOGGER ignored.";
                statustxtbox.Update();
            }
            else if (result == DialogResult.Cancel)
            {
                // do nothing
                // print message Exit cancelled
                statustxtbox.Text = "Force Exit of mySQM+ TCP/IP LOGGER cancelled.";
                statustxtbox.Update();
            }
        }

        private void ClearStatusMsgTimer_Tick(object sender, EventArgs e)
        {
            statustxtbox.Clear();
            statustxtbox.Update();
            ClearStatusMsgTimer.Stop();
        }

        private void statustxtbox_TextChanged(object sender, EventArgs e)
        {
            ClearStatusMsgTimer.Start();
        }

        private void resetLogfilesPathMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult dgresult;

            // clear the data logfilename etc
            // then ask user to disconnect and exit app and restart

            // disable data logging
            Properties.Settings.Default.DataLogFileEnabled = false;
            // disable error logging
            Properties.Settings.Default.ErrorLoggingEnabled = false;
            Properties.Settings.Default.Save();

            string PathStr = Properties.Settings.Default.LogPathName;
            if (PathStr == "")
            {
                PathStr = "<null>";
            }

            dgresult = MessageBox.Show("Current path is " + PathStr + System.Environment.NewLine + "Do you want to reset the path?", "mySQM+ TCP/IP LOGGER", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dgresult == System.Windows.Forms.DialogResult.Yes)
            {
                Properties.Settings.Default.LogPathName = "";
                Properties.Settings.Default.Save();
                MessageBox.Show("Press enter to reset the path - Application needs to be restarted for changes to take effect", "mySQM+ TCP/IP LOGGER", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Application.Exit();
            }
            else
            {
                // ignore
            }
        }

        private void LogValuesChkBox_CheckedChanged(object sender, EventArgs e)
        {
            string funcname = "LogValuesChkBox: ";
            LogMessageToErrorFile(funcname + "START======");
            // do nothing
            if (LogValuesChkBox.Checked == true)
            {
                LogMessageToErrorFile(funcname + "Logging enabled");
            }
            else
            {
                LogMessageToErrorFile(funcname + "Logging disabled");
            }
            LogMessageToErrorFile(funcname + "END======");
        }

        private void disableAlertPopUpMenuItem_Click(object sender, EventArgs e)
        {
            LogMessageToErrorFile("disableAlertPopUp: Disable rain alert");
            // alert pop up when raining disabled
            Properties.Settings.Default.RainingAlert = false;
            Properties.Settings.Default.Save();
            disableAlertPopoupMenuItem.Checked = true;
            enableAlertPopupMenuItem.Checked = false;
            statustxtbox.Text = "Rain alert disabled";
            statustxtbox.Update();
        }

        private void enableAlertPopUpMenuItem_Click(object sender, EventArgs e)
        {
            LogMessageToErrorFile("disableAlertPopUp: Enable rain alert");
            // alert pop up when raining enabled
            Properties.Settings.Default.RainingAlert = true;
            Properties.Settings.Default.Save();
            disableAlertPopoupMenuItem.Checked = false;
            enableAlertPopupMenuItem.Checked = true;
        }

        private void LogErrorsChkBox_CheckedChanged(object sender, EventArgs e)
        {
            string funcname = "LogErrorchkbox: ";

            if (LogErrorsChkBox.Checked == true)
            {
                LogMessageToErrorFile(funcname + "Log errors enabled");
            }
            else
            {
                LogMessageToErrorFile(funcname + "Log errors disabled");
            }
            Properties.Settings.Default.Save();
        }

        private void luxValuesMenuItem_Click(object sender, EventArgs e)
        {
            // pop up a messagebox
            String txtstr = "0.0001\t\tMoonless, overcast night sky (starlight)" + System.Environment.NewLine +
                "0.002\t\tMoonless clear night sky with airglow" + System.Environment.NewLine +
                "0.05-0.36\t\tFull moon on a clear night" + System.Environment.NewLine +
                "3.4\t\tDark limit of civil twilight under a clear sky" + System.Environment.NewLine +
                "20-50\t\tPublic areas with dark surroundings" + System.Environment.NewLine +
                "50\t\tFamily living room lights" + System.Environment.NewLine +
                "80\t\tOffice building hallway" + System.Environment.NewLine +
                "100\t\tVery dark overcast day" + System.Environment.NewLine +
                "320-500\t\tOffice lighting" + System.Environment.NewLine +
                "400\t\tSunrise or sunset on a clear day" + System.Environment.NewLine +
                "1000\t\tOvercast day" + System.Environment.NewLine +
                "10,000-5,000\tFull daylight (not direct sun)" + System.Environment.NewLine +
                "32,000-100,000\tDirect sunlight" + System.Environment.NewLine +
                "Source: Wikipedia";

            MessageBox.Show(txtstr, "mySQM+ TCP/IP LOGGER", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void automate30s_CheckedChanged(object sender, EventArgs e)
        {
            if (automate30s.Checked == true)
            {
                LogMessageToErrorFile("automate30s: 30s interval selected");
            }
            Properties.Settings.Default.Dataloggingrate = 30000;
            Properties.Settings.Default.Save();
            intervaltimer.Interval = 30000;
        }

        private void automate1m_CheckedChanged(object sender, EventArgs e)
        {
            if (automate1m.Checked == true)
            {
                LogMessageToErrorFile("automate1m: 1m interval selected");
            }
            Properties.Settings.Default.Dataloggingrate = 60000;
            Properties.Settings.Default.Save();
            intervaltimer.Interval = 60000;
        }

        private void automate5m_CheckedChanged(object sender, EventArgs e)
        {
            if (automate5m.Checked == true)
            {
                LogMessageToErrorFile("automate5m: 5m interval selected");
            }
            Properties.Settings.Default.Dataloggingrate = 60000 * 5;
            Properties.Settings.Default.Save();
            intervaltimer.Interval = 60000 * 5;
        }

        private void automate10m_CheckedChanged(object sender, EventArgs e)
        {
            if (automate10m.Checked == true)
            {
                LogMessageToErrorFile("automate10m: 10m interval selected");
            }
            Properties.Settings.Default.Dataloggingrate = 60000 * 10;
            Properties.Settings.Default.Save();
            intervaltimer.Interval = 60000 * 10;
        }

        private void automate15m_CheckedChanged(object sender, EventArgs e)
        {
            if (automate15m.Checked == true)
            {
                LogMessageToErrorFile("automate15m: 15m interval selected");
            }
            Properties.Settings.Default.Dataloggingrate = 60000 * 15;
            Properties.Settings.Default.Save();
            intervaltimer.Interval = 60000 * 15;
        }

        private void automate30m_CheckedChanged(object sender, EventArgs e)
        {
            if (automate30m.Checked == true)
            {
                LogMessageToErrorFile("automate30m: 30m interval selected");
            }
            Properties.Settings.Default.Dataloggingrate = 60000 * 30;
            Properties.Settings.Default.Save();
            intervaltimer.Interval = 60000 * 30;
        }

        private void setCloudSensorIILogfilenameMenuItem_Click(object sender, EventArgs e)
        {
            string funcname = "setCSIIfilename: ";

            LogMessageToErrorFile(funcname + "START======");
            CSFormActive = true;
            CloudSensorForm = new GetCloudSensorIILogFilename();
            CloudSensorForm.ShowDialog();
            while (CSFormActive == true)
                ;
            // now set filename path
            CSlogfilename = Properties.Settings.Default.CloudSensorIILogFilename;

            // now work out absolute paths and save back into settings
            // get full pathname for datalog
            String PathStr = Properties.Settings.Default.LogPathName;
            int pathlen = PathStr.Length;
            if (pathlen == 3)       // "D:\\" or "C:\\" - root directory
            {
                CSlogfilename = PathStr + CSlogfilename;
            }
            else
            {
                CSlogfilename = PathStr + "\\" + CSlogfilename;
            }
            // remove any extension and then add extension .txt
            if (CSlogfilename.IndexOf('.') > 0)
            {
                CSlogfilename = CSlogfilename.Substring(0, CSlogfilename.IndexOf('.')) + ".txt";
            }
            else
            {
                CSlogfilename = CSlogfilename + ".txt";
            }
            LogMessageToErrorFile(funcname + "filename = " + CSlogfilename);
            LogMessageToErrorFile(funcname + "END======");
        }

        private void getallbtn_Click(object sender, EventArgs e)
        {
            string funcname = "getallbtn: ";
            bool status;

            LogMessageToErrorFile(funcname + "START======");

            status = true;
            status = getallvaluesfromcontroller();
            // check for error, only log values if no error occurred
            if (status == false)
            {
                LogMessageToErrorFile(funcname + "err getallvaluesfromcontroller()");
                return;
            }

            // log data if enabled
            if (LogValuesChkBox.Checked == true)
            {
                LogMessageToErrorFile(funcname + "now write datavalues to datalog");
                writedatavaluestodatafile();
            }

            // if cloud sensor logging enabled
            if (CloudSensorIILogEnablechkbox.Checked == true)
            {
                LogMessageToErrorFile(funcname + "now write datavalues to cloud sensor II log");
                writecloudsensorfile();
            }

            LogMessageToErrorFile(funcname + "END======");
        }

        private void cloudsensor2filenametxtbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                // the text box is directly linked to Properties.Settings.Default.CloudSensorIILogFilename
                Properties.Settings.Default.Save();
                e.Handled = true;
                return;
            }
            // allow only numeric input and backspace (8)
            char ch = e.KeyChar;

            // handle digits, backspace and alphanumeric
            if (!Char.IsLetterOrDigit(ch) && (ch != 0x08))
            {
                e.Handled = true;
            }
        }

        private void CSII_test_write_file()
        {
            // check output string for CSII
            mytemperaturegroup.ambient = 32.1;
            mytemperaturegroup.dewpoint = 9.33;
            mytemperaturegroup.skyobject = 15.1;
            mytemperaturegroup.skyambient = 13.1;

            myweathergroup.humidity = 75;
            myweathergroup.raining = 1;
            myweathergroup.winddir = 45;
            myweathergroup.windspd = 20.3;

            mydarkskygroup.sqm = 3.12;
            mydarkskygroup.lux = 1000;
            mydarkskygroup.cloudcover = 33;
            mydarkskygroup.skystate = 0;

            CSIItestoutput = true;
            writecloudsensorfile();
            CSIItestoutput = false;
        }

        private void mySQMPLUSTCPIPLOGGER_KeyDown(object sender, KeyEventArgs e)
        {
            // R	refresh all values - 
            if (e.Alt && e.KeyCode == Keys.R)
            {
                this.Invoke(new EventHandler(getallbtn_Click));
            }
            // T	Test write CSII format
            if (e.Alt && e.KeyCode == Keys.T)
            {
                CSII_test_write_file();
            }
            // X    Exit
            // Done in Exit menu name E&xit
        }

        private void loggingstartstopbtn_Click(object sender, EventArgs e)
        {
            if (automaterunning == false)
            {
                automaterunning = true;
                logstatusvaluelbl.Text = "Running";
                loggingstartstopbtn.Text = "Stop";
                fetchdatalbl.Text = "..";
                //enable timer with interval
                int timerinterval;
                timerinterval = 60000;      // just set to a default in case
                if (automate30s.Checked)
                {
                    timerinterval = 30000;      // 30s
                }
                else if (automate1m.Checked)
                {
                    timerinterval = 60000;      // 60s = 1m
                }
                else if (automate5m.Checked)
                {
                    timerinterval = 60000 * 5;  // 5m
                }
                else if (automate10m.Checked)
                {
                    timerinterval = 60000 * 10; // 10m
                }
                else if (automate15m.Checked)
                {
                    timerinterval = 60000 * 15; // 15m
                }
                else if (automate30m.Checked)
                {
                    timerinterval = 60000 * 30;   // 30m
                }
                else
                {
                    timerinterval = 60000;     // in case of error set to 1m
                }
                Properties.Settings.Default.Dataloggingrate = timerinterval;
                Properties.Settings.Default.Save();
                intervaltimer.Interval = timerinterval;
                intervaltimer.Enabled = true;
                intervaltimer.Start();
            }
            else
            {
                automaterunning = false;
                intervaltimer.Stop();
                //disable timer
                intervaltimer.Enabled = false;
                logstatusvaluelbl.Text = "Stopped";
                loggingstartstopbtn.Text = "Start";
            }
        }

        private void windVeryWindytxtbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                // enter key has been pressed, so validate entry
                LogMessageToErrorFile("windVeryWindy = " + windVeryWindytxtbox.Text);
                windVeryWindy = Convert.ToDouble(windVeryWindytxtbox.Text, us_english);
                Properties.Settings.Default.windVeryWindy = windVeryWindy;
                Properties.Settings.Default.Save();
                e.Handled = true;
                return;
            }
            // allow only numeric input and backspace (8)
            char ch = e.KeyChar;

            // handle digits, dot and backspace
            if ((!Char.IsDigit(ch)) && (ch != '.') && (ch != 0x08))
            {
                e.Handled = true;
            }
        }

        private void windWindytxtbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                // enter key has been pressed, so validate entry
                LogMessageToErrorFile("windWindy = " + windWindytxtbox.Text);
                windWindy = Convert.ToDouble(windWindytxtbox.Text, us_english);
                Properties.Settings.Default.windWindy = windWindy;
                Properties.Settings.Default.Save();
                e.Handled = true;
                return;
            }
            // allow only numeric input and backspace (8)
            char ch = e.KeyChar;

            // handle digits, dot and backspace
            if ((!Char.IsDigit(ch)) && (ch != '.') && (ch != 0x08))
            {
                e.Handled = true;
            }
        }

        private void cloudVeryCloudytxtbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                // enter key has been pressed, so validate entry
                LogMessageToErrorFile("cloudVeryCloudy = " + cloudVeryCloudytxtbox.Text);
                cloudVeryCloudy = Convert.ToDouble(cloudVeryCloudytxtbox.Text, us_english);
                Properties.Settings.Default.cloudVeryCloudy = cloudVeryCloudy;
                Properties.Settings.Default.Save();
                e.Handled = true;
                return;
            }
            // allow only numeric input and backspace (8)
            char ch = e.KeyChar;

            // handle digits, dot and backspace
            if ((!Char.IsDigit(ch)) && (ch != '.') && (ch != 0x08))
            {
                e.Handled = true;
            }
        }

        private void cloudCloudytxtbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                // enter key has been pressed, so validate entry
                LogMessageToErrorFile("cloudCloudy = " + cloudCloudytxtbox.Text);
                cloudCloudy = Convert.ToDouble(cloudCloudytxtbox.Text, us_english);
                Properties.Settings.Default.cloudCloudy = cloudCloudy;
                Properties.Settings.Default.Save();
                e.Handled = true;
                return;
            }
            // allow only numeric input and backspace (8)
            char ch = e.KeyChar;

            // handle digits, dot and backspace
            if ((!Char.IsDigit(ch)) && (ch != '.') && (ch != 0x08))
            {
                e.Handled = true;
            }
        }

        private void dayVeryLighttxtbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                // enter key has been pressed, so validate entry
                LogMessageToErrorFile("dayVeryLight = " + dayVeryLighttxtbox.Text);
                dayVeryLight = Convert.ToDouble(dayVeryLighttxtbox.Text, us_english);
                Properties.Settings.Default.dayVeryLight = dayVeryLight;
                Properties.Settings.Default.Save();
                e.Handled = true;
                return;
            }
            // allow only numeric input and backspace (8)
            char ch = e.KeyChar;

            // handle digits, dot and backspace
            if ((!Char.IsDigit(ch)) && (ch != '.') && (ch != 0x08))
            {
                e.Handled = true;
            }
        }

        private void dayLighttxtbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                // enter key has been pressed, so validate entry
                LogMessageToErrorFile("dayLight = " + dayLighttxtbox.Text);
                dayLight = Convert.ToDouble(dayLighttxtbox.Text, us_english);
                Properties.Settings.Default.dayLight = dayLight;
                Properties.Settings.Default.Save();
                e.Handled = true;
                return;
            }
            // allow only numeric input and backspace (8)
            char ch = e.KeyChar;

            // handle digits, dot and backspace
            if ((!Char.IsDigit(ch)) && (ch != '.') && (ch != 0x08))
            {
                e.Handled = true;
            }
        }
    }
}
