mySQM+ TCPIPLOGGER Windows Application
(c) Robert Brown 2020-2021, All rights reserved.
brown_rb@yahoo.com

Permission is granted for personal/academic/education use only.

0.0.28
Update for new firmware 125+
Change logging output to only JSON (compatible with LogViewerPlus
Fix for automate radio buttons (sometimes interval is set incorrectly)

0.0.27
Add additional log messages
Extract code in getalldatavalues into seperate routines
Rewrite some of the interval timer code
Fix for some datalog issues

0.0.26
Fix for not writing datalog and cs2 file

0.0.25
Additional logging information
Change log filenames (too long)
Remove 10s/15s updates from logging tab - the data can take longer than 10s to arrive

0.0.24
Fix error in datalog file (rainfall curr day and prev hour)
Fix for logging Pressure in data log file
Fix for gps being blank in log file
Fix for datalogfile errors after cloudcover value
Add /about request and add firmware version to logfile (in place of NotConnected)
Add raincurrday, rainprevhr, rainprevday to datalog header line
Add additional error checking around data requests and logging data
Add additional error checking in the interval timer code
Add locale handling for all values

0.0.23
Adjustment of DayCondition boundaries


0.0.23
Adjustment of DayCondition boundaries

0.0.21
Additional Fixes
Add settings tab

0.0.20
Fix Raining issue (caused by JSON de-serialization error)
Fix locale issues for xx,xx which causes problems loading into Excel
Add rainfall to mySQM+ data logfile

0.0.19
Replace automate check box with Start/Stop logging button
code changes made to rain flag, wet flag, skystate, wind condition, rain condition, daylight condition

0.0.18
Extra logging to log JSON responses from server and deserialized results
Fixes for a number of values

0.0.17
Remove Boltwood

0.0.16
Rewrite cloud sensor file code

0.0.15
Add status indicator label for interval timer

0.0.14
Fix for data/time not showing in CSII log file

0.0.13
Add user ability to specify cloud sensor ii filename
Add socket read timeout values
Make sure cloud sensor data file is single line and new data overwrites old data

0.0.12
Remove graph button and seperate graph window

0.0.11
Move automate checkbox as it is clipped

0.0.10
Add 15s and 30s to logging interval
Make SQM/NELM graph larger
Make Temp Tab and move temp graph to that tab

0.0.9
Change name to mySQMPLUSTCPIPLOGGER

0.0.7
Change pressure to double

0.0.6
Fix bug for CS-II logfile cloudstate

0.0.5
Change logfile to write cloudstate as 0 or 1 instead of CLEAR / CLOUDY

0.0.4
Fix main graph lux showing as 1E etc - change to decimal places

0.0.3
Change Icon

0.0.2
Fix for wrong desktop icon name
Fix for sqm always being 0
Fix for no , in datalogfile after windspeed

0.0.1
Initial release